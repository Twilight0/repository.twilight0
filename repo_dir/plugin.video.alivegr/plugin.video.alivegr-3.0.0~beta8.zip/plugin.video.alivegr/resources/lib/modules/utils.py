# -*- coding: utf-8 -*-

# AliveGR Addon
# Author Twilight0
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

import os.path
from os import rename
from xbmcaddon import Addon
import pickled
import sqlite3
import copy
from itertags import iwrapper
import json
import re
from tulip import kodi, directory, cleantitle, bookmarks
from netclient import Net
from urllib.parse import parse_qsl, urlparse
from tulip.log import log
from .themes import iconname
from .constants import WEBSITE, PINNED, SEARCH_HISTORY, PLAYBACK_HISTORY, STREAM_PREFS, cache_duration
from .storage import TextListStorage
from tulip.kodi import update_repositories
from os import path
from time import time
from scrapetube.wrapper import list_playlist_videos, list_playlists


########################################################################################################################

reset_cache = pickled.FunctionCache(kodi.cacheDirectory).reset_cache
cache_function = pickled.FunctionCache(kodi.cacheDirectory).cache_function


def _get_history_size():
    try:
        return int(Addon().getSetting('history_size'))
    except Exception:
        return 50


PINNED_STORE = TextListStorage(PINNED)
PLAYBACK_STORE = TextListStorage(PLAYBACK_HISTORY, max_items=50)
SEARCH_STORE = TextListStorage(SEARCH_HISTORY, max_items=50)


def stream_picker(links):

    _choice = kodi.selectDialog(heading=kodi.i18n(30006), list=[link[0] for link in links])

    if _choice <= len(links) and not _choice == -1:
        popped = [link[1] for link in links][_choice]
        return popped


def i18n():

    lang = 'el_GR' if 'Greek' in kodi.infoLabel('System.Language') else 'en_GB'

    return lang


def thumb_maker(video_id, hq=False):

    return 'http://img.youtube.com/vi/{0}/{1}.jpg'.format(video_id, 'mqdefault' if not hq else 'maxresdefault')


def reset_idx(notify=True, forceit=False):

    if Addon().getSetting('reset_idx') == 'true' or forceit:

        if Addon().getSetting('reset_live') == 'true' or forceit:

            kodi.setSetting('live_group', '0')

        kodi.setSetting('vod_group', '30213')
        kodi.setSetting('papers_group', '0')

        if notify:
            kodi.infoDialog(message=kodi.i18n(30402), time=3000)

        log('Indexers have been reset')


def papers():

    kodi.execute('Dialog.Close(all)')
    kodi.execute('ActivateWindow(10002,"plugin://plugin.video.alivegr/?content_type=image",return)')


def activate_other_addon(url, query=None):

    if not url.startswith('plugin://'):
        url = ''.join(['plugin://', url, '/'])

    parsed = urlparse(url)

    if not kodi.condVisibility('System.HasAddon({0})'.format(parsed.netloc)):
        kodi.execute('InstallAddon({0})'.format(parsed.netloc))

    params = dict(parse_qsl(parsed.query))
    action = params.get('action')
    url = params.get('url')

    directory.run_builtin(addon_id=parsed.netloc, action=action, url=url, content_type=query)


def cache_clear(notify=True):

    log('Cache has been cleared')
    reset_cache()
    if notify:
        kodi.infoDialog(kodi.i18n(30402))


def purge_bookmarks():

    if path.exists(kodi.bookmarksFile):
        if kodi.yesnoDialog(line1=kodi.i18n(30214)):
            kodi.deleteFile(kodi.bookmarksFile)
            kodi.infoDialog(kodi.i18n(30402))
            kodi.refresh()
        else:
            kodi.infoDialog(kodi.i18n(30403))
    else:
        kodi.infoDialog(kodi.i18n(30139))


def clear_search_history():

    if path.exists(SEARCH_HISTORY):
        if kodi.yesnoDialog(line1=kodi.i18n(30484).format(path.basename(SEARCH_HISTORY))):
            kodi.deleteFile(SEARCH_HISTORY)
            kodi.infoDialog(kodi.i18n(30402))
            kodi.refresh()
        else:
            kodi.infoDialog(kodi.i18n(30403))
    else:
        kodi.infoDialog(kodi.i18n(30347))


def clear_playback_history():

    if path.exists(PLAYBACK_HISTORY):
        if kodi.yesnoDialog(line1=kodi.i18n(30484).format(path.basename(PLAYBACK_HISTORY))):
            kodi.deleteFile(PLAYBACK_HISTORY)
            kodi.infoDialog(kodi.i18n(30402))
            kodi.refresh()
        else:
            kodi.infoDialog(kodi.i18n(30403))
    else:
        kodi.infoDialog(kodi.i18n(30347))


def tools_menu():

    kodi.execute('Dialog.Close(all)')

    kodi.execute('ActivateWindow(programs,"plugin://plugin.video.alivegr/?content_type=executable",return)')


def call_info():

    kodi.close_all()

    kodi.execute('ActivateWindow(programs,"plugin://plugin.video.alivegr/?content_type=executable&action=info",return)')


def greeting():

    kodi.infoDialog(kodi.i18n(30263))


def refresh():

    kodi.refresh()


def refresh_and_clear():

    cache_clear()
    kodi.sleep(100)
    refresh()


def geo_loc():
    json_obj = None
    for url in (
        'https://geoip.siliconweb.com/geo.json',
        'https://ip-api.com/json/',
        'https://extreme-ip-lookup.com/json/'
    ):
        try:
            res = Net().http_GET(url).get_json()
            if res and isinstance(res, dict) and res.get('country') and not res.get('error'):
                json_obj = res
                break
        except Exception:
            continue

    if not json_obj:
        return 'Worldwide'

    return json_obj.get('country', 'Worldwide')


def pin_to_file(file_, txt):
    if not txt:
        return
    TextListStorage(file_).add(txt)


def pinned_from_file(file_):
    res = TextListStorage(file_).get_reversed()
    return res if res else ['']


def unpin_from_file(file_, txt):
    if not txt:
        return
    TextListStorage(file_).remove(txt)


def pin(query):

    kodi.busy()

    # title = kodi.infoLabel('ListItem.Title')
    # pin_to_file(PINNED, title)
    pin_to_file(PINNED, query)

    kodi.infoDialog(kodi.i18n(30338), time=750)

    kodi.idle()


def unpin(query):

    kodi.busy()

    # title = kodi.infoLabel('ListItem.Title')
    # unpin_from_file(PINNED, title)
    unpin_from_file(PINNED, query)

    kodi.sleep(100)
    kodi.refresh()

    kodi.infoDialog(kodi.i18n(30338), time=750)

    kodi.idle()


def get_all_stream_prefs():
    """Retrieve all stream preferences from JSON file as a dict."""
    if not kodi.exists(STREAM_PREFS):
        return {}
    try:
        with open(STREAM_PREFS, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log(f"Error loading stream preferences: {e}")
        return {}


def get_stream_pref(title, prefs=None):
    """Retrieve stream preference (index or None) for a channel title with fuzzy matching."""
    if prefs is None:
        prefs = get_all_stream_prefs()
    if not prefs or not title:
        return None
    if title in prefs:
        return prefs[title]
    t_lower = title.lower().strip()
    for k, v in prefs.items():
        if k.lower().strip() == t_lower:
            return v
    # Handle sport vs sports variation
    t_sport = re.sub(r'\bsports\b', 'sport', t_lower)
    for k, v in prefs.items():
        k_sport = re.sub(r'\bsports\b', 'sport', k.lower().strip())
        if k_sport == t_sport:
            return v
    return None


def set_stream_pref(title, index):
    """Save stream preference index for a channel title."""
    if not kodi.exists(STREAM_PREFS):
        kodi.makeFiles(kodi.dataPath)
    prefs = get_all_stream_prefs()
    prefs[title] = index
    try:
        with open(STREAM_PREFS, 'w', encoding='utf-8') as f:
            json.dump(prefs, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Error saving stream preferences: {e}")


########################################################################################################################


def file_to_text(file_):

    try:

        with open(file_, encoding='utf-8') as text:
            result = text.read()

    except Exception:

        with open(file_) as text:
            result = text.read()

    return result


def trim_content(f):
    history_size = _get_history_size()
    TextListStorage(f, max_items=history_size).trim()


def add_to_file(f, text, trim_file=True):
    if not text:
        return

    history_size = _get_history_size() if trim_file else None
    TextListStorage(f, max_items=history_size).add(text, trim=trim_file)


def process_file(f, text, mode='remove'):
    store = TextListStorage(f)

    if mode == 'change':
        lines = store.get_all()
        if text in lines:
            search_type, _, search_term = text.partition(',')
            str_input = kodi.inputDialog(heading=kodi.i18n(30445), default=search_term)
            if not str_input:
                return None
            str_input = cleantitle.strip_accents(str_input)
            new_text = ','.join([search_type, str_input])
            store.replace(text, new_text)
        else:
            return
    else:
        store.remove(text)

    kodi.refresh()


def read_from_file(f):
    """
    Reads from history file which is stored in plain text, line by line
    :return: List
    """
    if kodi.exists(f):
        return TextListStorage(f).get_reversed()
    else:
        return


########################################################################################################################


def changelog(get_text=False):

    if Addon().getSetting('changelog_lang') == '0' and 'Greek' in kodi.infoLabel('System.Language'):
        change_txt = 'changelog.el.txt'
    elif (
            Addon().getSetting('changelog_lang') == '0' and 'Greek' not in kodi.infoLabel('System.Language')
    ) or Addon().getSetting('changelog_lang') == '1':
        change_txt = 'changelog.en.txt'
    else:
        change_txt = 'changelog.el.txt'

    change_txt = kodi.join(kodi.addonPath, 'resources', 'texts', change_txt)

    if get_text:
        return file_to_text(change_txt).partition(u'\n\n')[0]
    else:
        kodi.dialog.textviewer(kodi.addonInfo('name') + ', ' + kodi.i18n(30110), file_to_text(change_txt))


def dmca():

    location = kodi.join(
        kodi.transPath(kodi.addonInfo('path')), 'resources', 'texts', 'dmca_{0}.txt'.format(i18n())
    )

    kodi.dialog.textviewer(kodi.addonInfo('name'), file_to_text(location))


def pp():

    location = kodi.join(
        kodi.transPath(kodi.addonInfo('path')), 'resources', 'texts', 'pp_{0}.txt'.format(i18n())
    )

    kodi.dialog.textviewer(kodi.addonInfo('name'), file_to_text(location))


def disclaimer():

    text = kodi.addonInfo('disclaimer')
    kodi.dialog.textviewer(kodi.addonInfo('name') + ', ' + kodi.i18n(30129), text)


def do_not_ask_again():

    kodi.setSetting('new_version_prompt', 'false')

    kodi.okDialog('AliveGR', kodi.i18n(30361))


def prompt():

    kodi.okDialog('AliveGR', kodi.i18n(30356).format(remote_version()))

    choices = [kodi.i18n(30357), kodi.i18n(30358), kodi.i18n(30359)]

    _choice = kodi.selectDialog(choices, heading=kodi.i18n(30482))

    if _choice == 0:
        update_repositories()
    elif _choice == 1:
        kodi.close_all()
    elif _choice == 2:
        do_not_ask_again()


def welcome():

    choices = [kodi.i18n(30329), kodi.i18n(30340), kodi.i18n(30129), kodi.i18n(30333)]

    _choice = kodi.selectDialog(choices, heading=kodi.i18n(30267).format(kodi.version()))

    if _choice in [0, -1]:
        kodi.close_all()
    elif _choice == 1:
        changelog()
    elif _choice == 2:
        disclaimer()
    elif _choice == 3:
        kodi.open_web_browser(WEBSITE)


def new_version(new=False):

    version_file = kodi.join(kodi.dataPath, 'version.txt')

    if not path.exists(version_file) or new:

        if not path.exists(kodi.dataPath):

            kodi.makeFile(kodi.dataPath)

        try:
            with open(version_file, mode='w', encoding='utf-8') as f:
                f.write(kodi.version())
        except Exception:
            with open(version_file, 'w') as f:
                f.write(kodi.version())

        return True

    else:

        try:
            with open(version_file, encoding='utf-8') as f:
                version = f.read()
        except Exception:
            with open(version_file) as f:
                version = f.read()

        if version != kodi.version():
            return new_version(new=True)
        else:
            return False


@cache_function(cache_duration(360))
def remote_version():

    url = 'https://raw.githubusercontent.com/Twilight0/repository.twilight0/refs/heads/master/repo_dir/plugin.video.alivegr/addon.xml'
    xml = Net().http_GET(url).content

    version = iwrapper(xml, 'addon', attrs={'id': kodi.addonInfo('id')}, ret='version').__next__()

    version = int(version.replace('.', ''))

    return version


########################################################################################################################


def rename_history_csv():

    try:
        if not kodi.exists(SEARCH_HISTORY):
            rename(SEARCH_HISTORY.replace('search_', ''), SEARCH_HISTORY)
    except Exception:
        pass


def checkpoint():

    check = time() + 10800

    try:
        new_version_prompt = Addon().getSetting('new_version_prompt') == 'true' and remote_version() > int(kodi.version().replace('.', ''))
    except ValueError:  # will fail if version install is alpha or beta
        new_version_prompt = False

    rename_history_csv()

    if new_version():

        # if kodi.yesnoDialog(kodi.i18n(30267)):
        #     changelog()
        welcome()

        cache_clear(notify=False)
        reset_idx(notify=False)
        clean_old_textures()

        if Addon().getSetting('debug') == 'true':

            log(
                'Debug settings have been reset, please do not touch these settings manually,'
                ' they are *only* meant to help developer test various aspects.'
            )

            kodi.setSetting('debug', 'false')

        kodi.setSetting('last_check', str(check))

    elif new_version_prompt and time() > float(Addon().getSetting('last_check')):

        prompt()
        kodi.setSetting('last_check', str(check))


def clean_old_textures():

    base_path = kodi.transPath('special://profile/')
    textures_path = kodi.join(base_path, 'Thumbnails')
    db_path = kodi.join(base_path, 'Database/Textures13.db')

    try:

        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()

        # Find the cached filenames for your specific assets
        query = "SELECT cachedurl FROM texture WHERE url LIKE ? OR url LIKE ?"
        params = (f"%{kodi.addonInfo('id')}/icon.png", f"%{kodi.addonInfo('id')}/fanart.jpg")

        cursor.execute(query, params)
        rows = cursor.fetchall()

        for (cached_rel_path,) in rows:

            full_file_path = kodi.join(textures_path, cached_rel_path)

            if kodi.exists(full_file_path):
                kodi.deleteFile(full_file_path)

    except sqlite3.Error as e:
        log(f"Error reading database: {e}")
    finally:
        if 'conn' in locals():
            conn.close()


def page_selector(query):

    pages = [kodi.i18n(30415).format(i) for i in list(range(1, int(query) + 1))]

    _choice = kodi.selectDialog(pages, heading=kodi.i18n(30416))

    if _choice != -1:

        kodi.setSetting('page', str(_choice))
        kodi.sleep(200)
        kodi.refresh()

        if Addon().getSetting('pagination_reset') == 'true':
            # wait a second in order to ensure container is first loaded then reset the page
            kodi.sleep(1000)
            kodi.setSetting('page', '0')


def page_menu(pages, reset=False):

    if not reset:
        index = str(int(Addon().getSetting('page')) + 1)
    else:
        index = '1'

    menu = {
        'title': kodi.i18n(30414).format(index),
        'action': 'page_selector',
        'query': pages,
        'icon': iconname('switcher'),
        'isFolder': 'False',
        'isPlayable': 'False'
    }

    return menu


@cache_function(cache_duration(60))
def yt_playlist(url):

    return list_playlist_videos(url)


@cache_function(cache_duration(480))
def yt_playlists(url):

    return list_playlists(url)

########################################################################################################################

def lists_merger(list_1, list_2, key='title'):

    merged_list = copy.deepcopy(list_1)

    matched_list_2_indices = set()

    for item1 in merged_list:
        title1 = item1[key].lower().strip()

        for i, item2 in enumerate(list_2):
            title2 = item2[key].lower()

            if title1 in title2:

                if 'plot' in item2:
                    item1['plot'] = item2['plot']

                if 'image' in item2:
                    item1['image'] = item2['image']

                if 'genre' in item2:
                    item1['genre'] = item2['genre']

                matched_list_2_indices.add(i)

                break

    for i, item2 in enumerate(list_2):
        if i not in matched_list_2_indices:
            merged_list.append(item2)

    return sorted(merged_list, key=lambda x: x[key])
