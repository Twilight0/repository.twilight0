# -*- coding: utf-8 -*-

'''
    Alpha Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENCES/GPL-3.0-only for more information.
'''

import json
import os
import re
import threading
from urllib.parse import quote_plus

import xbmc
import xbmcgui

from . import api, player
from .constants import (
    REGION_GR, REGION_CY, REGIONS, GR_LIVE_PAGE, CY_LIVE_PAGE, GR_NEWS_SECTIONS,
    CY_CATEGORIES, bookmarks_file
)
from tulip import kodi, directory, bookmarks
from tulip.init import sysaddon
from tulip.utils import iteritems
from urldispatcher import urldispatcher

try:
    from pickled import FunctionCache

    cache = FunctionCache(kodi.cacheDirectory)
    cache_function = cache.cache_function
except Exception:
    def cache_function(limit, limit_mode=60):
        def wrap(func):
            return func
        return wrap


def i18n(number):
    try:
        return kodi.i18n(number)
    except Exception:
        return str(number)


def _json(value):
    return json.dumps(value, separators=(',', ':'))


def _ref(**kwargs):
    """A listing is fully described by this dict, passed around as its url."""

    return _json(kwargs)


def _browseable(item, **overrides):
    bookmark = dict((k, v) for k, v in iteritems(item) if k not in ('next', 'cm'))
    bookmark.update(overrides)
    bookmark['bookmark'] = bookmark.get('url')
    return [{'title': 30501, 'query': {'action': 'addBookmark', 'url': _json(bookmark)}}]


def _empty(label):
    return [{'title': label, 'action': None, 'isFolder': 'False', 'isPlayable': 'False'}]


def _context_menu():

    return [
        {'title': 30022, 'query': {'action': 'clear_cache'}},
        {'title': 30026, 'query': {'action': 'settings'}},
    ]


def _region():
    try:
        region = kodi.setting('region')
    except Exception:
        region = ''

    return region if region in (REGION_GR, REGION_CY) else REGION_GR


def _selector_mode():
    try:
        mode = kodi.setting('selector_mode')
    except Exception:
        mode = ''

    # '0' (dedicated line) is the default; only an explicit '1' hides it.
    return '1' if mode == '1' else '0'


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------

@urldispatcher.register('root')
def root():

    if _region() == REGION_CY:
        cy_icons = {
            'all': 'shows.png',
            'ellinikes-seires': 'series.png',
            'entertainment': 'shows.png',
            'informative': 'shows.png',
            'news': 'news.png',
            'guests': 'guests.png',
            'cooking': 'cooking.png',
        }
        menu = [{'title': i18n(30001), 'action': 'live', 'isPlayable': 'True',
                 'image': kodi.addonmedia('live.png')}]
        for category, label in CY_CATEGORIES:
            icon_name = cy_icons.get(category, 'shows.png')
            menu.append({
                'title': i18n(label),
                'action': 'listing',
                'url': _ref(kind='cy_category', category=category),
                'isFolder': 'True',
                'image': kodi.addonmedia(icon_name),
            })
        menu.append({
            'title': i18n(30066),
            'action': 'listing',
            'url': _ref(kind='cy_movies'),
            'isFolder': 'True',
            'image': kodi.addonmedia('movies.png'),
        })
    else:
        menu = [
            {'title': i18n(30001), 'action': 'live', 'isPlayable': 'True',
             'image': kodi.addonmedia('live.png')},
            {'title': i18n(30002), 'action': 'listing', 'url': _ref(kind='series'),
             'isFolder': 'True', 'image': kodi.addonmedia('series.png')},
            {'title': i18n(30008), 'action': 'listing', 'url': _ref(kind='shows'),
             'isFolder': 'True', 'image': kodi.addonmedia('shows.png')},
            {'title': i18n(30066), 'action': 'listing', 'url': _ref(kind='movies'),
             'isFolder': 'True', 'image': kodi.addonmedia('movies.png')},
            {'title': i18n(30012), 'action': 'listing', 'url': _ref(kind='broadcasts'),
             'isFolder': 'True', 'image': kodi.addonmedia('recent.png')},
            {'title': i18n(30011), 'action': 'news', 'isFolder': 'True',
             'image': kodi.addonmedia('news.png')},
        ]

    menu.append({'title': i18n(30009), 'action': 'bookmarks', 'isFolder': 'True',
                 'image': kodi.addonmedia('bookmarks.png')})

    if _selector_mode() == '0':
        # Dedicated selector line, AliveGR-style: an action, not a folder.
        menu.append({
            'title': i18n(30003).format(i18n(dict(REGIONS)[_region()])),
            'action': 'selector',
            'isFolder': 'False',
            'isPlayable': 'False',
            'image': kodi.addonmedia('selector.png'),
        })
    else:
        for item in menu:
            item['cm'] = item.get('cm', _context_menu()) + [{
                'title': 30007,
                'query': {'action': 'selector'},
            }]

    for item in menu:
        item.setdefault('cm', _context_menu())

    directory.builder(menu, content='videos')


@urldispatcher.register('news')
def news():

    menu = []

    for section, label in GR_NEWS_SECTIONS:
        menu.append({
            'title': i18n(label),
            'action': 'listing',
            'url': _ref(kind='news', section=section),
            'isFolder': 'True',
            'image': kodi.addonmedia('news.png'),
        })

    for item in menu:
        item['cm'] = _context_menu()

    directory.builder(menu, content='videos')


@urldispatcher.register('categories', ['url'])
def categories(url=''):
    """Cyprus only: the Drupal archive categories."""

    menu = []

    for category, label in CY_CATEGORIES:
        menu.append({
            'title': i18n(label),
            'action': 'listing',
            'url': _ref(kind='cy_category', category=category),
            'isFolder': 'True',
        })

    for item in menu:
        item['cm'] = _context_menu()

    directory.builder(menu, content='videos')


@urldispatcher.register('selector')
def selector():

    chosen = kodi.selectDialog([i18n(label) for _, label in REGIONS])

    if chosen == -1:
        return

    if REGIONS[chosen][0] == _region():
        return

    kodi.setSetting('region', REGIONS[chosen][0])

    # Container.Refresh alone reuses the cached listing, so jump back to a
    # rebuilt root instead; it also covers the settings-dialog entry point.
    kodi.execute('Container.Update({0}?action=root,replace)'.format(sysaddon))


@urldispatcher.register('switch')
def switch():
    """Legacy alias, so bookmarks made by older versions keep working."""

    selector()


@urldispatcher.register('navigate', ['target'])
def navigate(target):
    """Navigates the current container to a target URL (e.g. season index or root)."""

    if target == 'root':
        kodi.execute('Container.Update("{0}?action=root")'.format(sysaddon))
    elif target.startswith('ref:'):
        raw_ref = target[4:]
        kodi.execute('Container.Update("{0}?action=listing&url={1}")'.format(
            sysaddon, quote_plus(raw_ref)))
    else:
        kodi.execute('Container.Update("{0}")'.format(target))


def _display_overlay_worker(text, duration=10.0):
    """
    Displays the page indicator overlay non-modally by adding controls
    directly to the active media window (or window 10000).
    This guarantees 0% blocking of list navigation.
    """
    try:
        addon_path = kodi.addonInfo('path')
        texture_path = os.path.join(addon_path, 'resources', 'skins', 'Default', 'media', 'bg_card.png')

        try:
            pos_setting = int(kodi.setting('overlay_position'))
        except Exception:
            pos_setting = 0

        try:
            pad_x = int(float(kodi.setting('overlay_padding_x')))
        except Exception:
            pad_x = 40

        try:
            pad_y = int(float(kodi.setting('overlay_padding_y')))
        except Exception:
            pad_y = 30

        win_id = xbmcgui.getCurrentWindowId()
        if not win_id or win_id == -1:
            win_id = 10025  # MyVideoNav
        win = xbmcgui.Window(win_id)

        try:
            win_w = win.getWidth()
            win_h = win.getHeight()
        except Exception:
            win_w = 0
            win_h = 0

        if not win_w or win_w <= 0:
            win_w = 1920
        if not win_h or win_h <= 0:
            win_h = 1080

        # Scale badge dimensions proportionally with reference 1080p (width ~300, height ~56)
        scale_x = win_w / 1920.0
        scale_y = win_h / 1080.0
        badge_w = int(max(200, 300 * scale_x))
        badge_h = int(max(40, 56 * scale_y))

        if pos_setting == 1:  # top-left
            x = pad_x
            y = pad_y
        elif pos_setting == 2:  # bottom-right
            x = win_w - badge_w - pad_x
            y = win_h - badge_h - pad_y
        elif pos_setting == 3:  # bottom-left
            x = pad_x
            y = win_h - badge_h - pad_y
        else:  # 0: top-right (default)
            x = win_w - badge_w - pad_x
            y = pad_y

        # Non-focusable controls attached directly to the window
        # Alignment 6 = ALIGN_CENTER_X (2) | ALIGN_CENTER_Y (4)
        img_control = xbmcgui.ControlImage(int(x), int(y), badge_w, badge_h, texture_path)
        lbl_control = xbmcgui.ControlLabel(
            int(x + 10), int(y), badge_w - 20, badge_h,
            text, font='font13', textColor='0xFFFFFFFF', alignment=6
        )

        win.addControl(img_control)
        win.addControl(lbl_control)

        # Sleep for the duration, checking abortRequested periodically
        sleep_steps = int(duration * 10)
        for _ in range(sleep_steps):
            if xbmc.Monitor().abortRequested():
                break
            xbmc.sleep(100)

        try:
            win.removeControl(lbl_control)
        except Exception:
            pass
        try:
            win.removeControl(img_control)
        except Exception:
            pass
        del lbl_control
        del img_control
    except Exception:
        pass


def _show_page_overlay(text):
    t = threading.Thread(target=_display_overlay_worker, args=(text,))
    t.daemon = True
    t.start()


@urldispatcher.register('change_page', ['url', 'current', 'total'])
def change_page(url, current, total):
    """Allows jumping directly to an episode page."""
    try:
        total_p = int(total)
        current_p = int(current)
    except Exception:
        total_p = 1
        current_p = 1

    prompt = i18n(30056)
    if total_p > 1:
        prompt = '{0} (1-{1})'.format(prompt, total_p)

    val = kodi.inputDialog(heading=prompt, default=str(current_p), type=xbmcgui.INPUT_NUMERIC)
    if not val:
        return

    try:
        target_page = int(val)
    except ValueError:
        return

    if target_page < 1:
        target_page = 1
    elif target_page > total_p:
        target_page = total_p

    try:
        ref_dict = json.loads(url)
        is_zero_based = ref_dict.get('kind') in ('cy_category', 'cy_episodes', 'cy_movies')
    except Exception:
        is_zero_based = False

    query_page = (target_page - 1) if is_zero_based else target_page

    target_url = '{0}?action=listing&url={1}&query={2}'.format(
        sysaddon, quote_plus(url), query_page)
    kodi.execute('Container.Update("{0}")'.format(target_url))


# ---------------------------------------------------------------------------
# Listings
#
# One route serves every folder. ``url`` is the ref dict and ``query`` the page
# number. WordPress counts pages from 1 and Drupal from 0, so the base is part
# of the ref rather than assumed.
# ---------------------------------------------------------------------------

@cache_function(12, 60)
def _catalogue(kind):
    return api.series() if kind == 'series' else api.shows()


@cache_function(12, 60)
def _seasons_of(base):
    return api.seasons(base)


@cache_function(6, 60)
def _movies(page):
    return api.movies(page)


@cache_function(6, 60)
def _cy_movies(page):
    return api.cy_movies(page)


@urldispatcher.register('listing', ['url'], ['query'])
def listing(url, query=None):

    try:
        ref = json.loads(url)
    except Exception:
        directory.builder(_empty(i18n(30033)), content='videos')
        return

    kind = ref.get('kind', '')

    try:
        if kind in ('shows', 'series'):
            _catalogue_listing(kind)
            return

        if kind == 'seasons':
            seasons_list = _seasons(ref)
            if not seasons_list:
                # Fallback to direct episodes if no seasons parsed
                ref['kind'] = 'episodes'
                listing(_json(ref), query)
                return
            directory.builder(seasons_list, content='videos')
            return

        page = int(query) if query not in (None, '') else _base_page(kind)

        if kind == 'broadcasts':
            items, previous, following, total_pages = api.broadcasts(page)
            page_text = i18n(30055).format(page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda v: _video_item(v, ref, page=page, total_pages=total_pages)))

        elif kind == 'episodes':
            items, previous, following, total_pages = api.episodes(
                ref['base'], page=page, season=ref.get('season'))
            page_text = i18n(30055).format(page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda v: _video_item(v, ref, page=page, total_pages=total_pages)))

        elif kind == 'news':
            items, previous, following, total_pages = api.news(ref['section'], page)
            _render(_page(kind, ref, page, previous, following, items, _article_item))

        elif kind == 'cy_category':
            items, previous, following, total_pages = api.cy_shows(ref['category'], page)
            display_page = page + 1
            page_text = i18n(30055).format(display_page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda v: _video_item(v, ref, page=display_page, total_pages=total_pages)))

        elif kind == 'cy_episodes':
            items, previous, following, total_pages = api.cy_episodes(ref['base'], page)
            display_page = page + 1
            page_text = i18n(30055).format(display_page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda v: _video_item(v, ref, page=display_page, total_pages=total_pages)))

        elif kind == 'movies':
            items, previous, following, total_pages = _movies(page)
            page_text = i18n(30055).format(page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda m: _movie_item(m, ref, page=page, total_pages=total_pages)))

        elif kind == 'cy_movies':
            items, previous, following, total_pages = _cy_movies(page)
            display_page = page + 1
            page_text = i18n(30055).format(display_page, total_pages)
            _show_page_overlay(page_text)
            _render(_page(kind, ref, page, previous, following, items,
                          lambda m: _movie_item(m, ref, page=display_page, total_pages=total_pages)))

        else:
            directory.builder(_empty(i18n(30014)), content='videos')

    except Exception as error:
        kodi.infoDialog('{0}: {1}'.format(i18n(30033), error))
        directory.builder(_empty(i18n(30033)), content='videos')


def _base_page(kind):
    return 0 if kind in ('cy_category', 'cy_episodes', 'cy_movies') else 1


def _catalogue_listing(kind):

    built = []

    for entry in _catalogue(kind):
        target_kind = 'seasons' if kind == 'series' else 'episodes'
        item = {
            'title': entry['title'],
            'action': 'listing',
            'url': _ref(kind=target_kind, base=entry['url'], title=entry['title']),
            'isFolder': 'True',
        }

        if entry.get('image'):
            item['image'] = entry['image']
            item['fanart'] = entry['image']

        item['cm'] = _browseable(item)
        if kind == 'series':
            item['cm'].append({
                'title': i18n(30052),
                'query': {'action': 'listing', 'url': _ref(
                    kind='episodes', base=entry['url'], title=entry['title'])},
            })

        built.append(item)

    kodi.setsortmethod('title')
    directory.builder(built or _empty(i18n(30014)), content='videos')


def _seasons(ref):

    base = ref['base']
    built = []
    seasons = _seasons_of(base)
    if not seasons:
        return []

    for season in seasons:
        item = {
            'title': season['title'],
            'action': 'listing',
            'url': _ref(kind='episodes', base=base, season=season['season'],
                        title=ref.get('title')),
            'isFolder': 'True',
        }
        item['cm'] = _browseable(item)
        built.append(item)

    # Offer an "All episodes" folder inside seasons for completeness
    all_episodes_item = {
        'title': i18n(30052),
        'action': 'listing',
        'url': _ref(kind='episodes', base=base, title=ref.get('title')),
        'isFolder': 'True',
    }
    all_episodes_item['cm'] = _browseable(all_episodes_item)
    built.append(all_episodes_item)

    return built


def _page_items(kind, ref, page, has_previous, has_next):
    """The "Previous page" / "Next page" entries, shared by every listing."""

    ref_url = _ref(**dict(ref, kind=kind))
    base = _base_page(kind)
    previous, following = None, None

    if has_previous and page > base:
        previous = {
            'title': i18n(30030),
            'action': 'listing',
            'url': ref_url,
            'query': str(page - 1),
            'isFolder': 'True',
            'image': kodi.addonmedia('previous.png'),
        }

    if has_next:
        following = {
            'title': i18n(30031),
            'action': 'listing',
            'url': ref_url,
            'query': str(page + 1),
            'isFolder': 'True',
            'image': kodi.addonmedia('next.png'),
        }

    return previous, following


def _page(kind, ref, page, has_previous, has_next, entries, make_item):
    """
    Wraps ``entries`` in a page: an optional "Previous page" entry, the
    entries themselves, and an optional "Next page" entry.
    """

    previous, following = _page_items(kind, ref, page, has_previous, has_next)

    if not entries:
        return _empty(i18n(30014))

    built = [previous] if previous else []

    built.extend(make_item(entry) for entry in entries)

    if following:
        built.append(following)

    return built


def _video_item(video, ref=None, page=1, total_pages=1):
    ref = ref or {}
    raw_title = video['title']
    show_title = ref.get('title')

    if show_title and not raw_title.startswith(show_title):
        display_title = '{0} - {1}'.format(show_title, raw_title)
    else:
        display_title = raw_title

    item = {
        'title': display_title,
        'action': 'play',
        'url': video['url'],
        'isFolder': 'False',
        'isPlayable': 'True',
    }

    if video.get('plot'):
        item['plot'] = video['plot']
        item['plotoutline'] = video['plot']

    s_fold = raw_title.casefold()
    season_match = re.search(r'(?:σ(?:εζον)?|s(?:eason)?)\s*-?\s*(\d+)', s_fold)
    ep_match = re.search(r'(?:επεισ[οό]δι[οό]|eps?|epeisodio|e)\s*-?\s*(\d+)', s_fold)

    season_num = int(season_match.group(1)) if season_match else ref.get('season')
    if season_num:
        item['season'] = str(season_num)

    if ep_match:
        item['episode'] = ep_match.group(1)

    if show_title:
        item['tvshowtitle'] = show_title
        item['mediatype'] = 'episode'

    if video.get('image'):
        item['image'] = video['image']
        item['fanart'] = video['image']

    cm = _browseable(item)

    if ref.get('base') and ref.get('kind') == 'episodes':
        season_ref = 'ref:' + _ref(kind='seasons', base=ref['base'], title=ref.get('title'))
        cm.append({
            'title': 30053,
            'query': {'action': 'navigate', 'target': season_ref},
        })

    cm.append({
        'title': 30054,
        'query': {'action': 'navigate', 'target': 'root'},
    })

    if ref.get('kind') in ('episodes', 'broadcasts', 'cy_category', 'cy_episodes') and total_pages > 1:
        cm.append({
            'title': 30056,
            'query': {
                'action': 'change_page',
                'url': _json(ref),
                'current': str(page),
                'total': str(total_pages)
            },
        })

    item['cm'] = cm

    return item


def _movie_item(movie, ref=None, page=1, total_pages=1):
    ref = ref or {}
    title = movie['title']

    item = {
        'title': title,
        'action': 'play_trailer',
        'url': _ref(title=title),
        'isFolder': 'False',
        'isPlayable': 'True',
        'mediatype': 'movie',
    }

    for tag in ('plot', 'plotoutline', 'tagline', 'mpaa', 'year', 'duration', 'director', 'writer', 'cast', 'genre'):
        if movie.get(tag):
            item[tag] = movie[tag]

    if 'plot' in movie and 'plotoutline' not in item:
        item['plotoutline'] = movie['plot']

    if movie.get('image'):
        item['image'] = movie['image']
        item['fanart'] = movie['image']

    cm = _browseable(item)
    cm.append({
        'title': 30054,
        'query': {'action': 'navigate', 'target': 'root'},
    })

    if total_pages > 1:
        cm.append({
            'title': 30056,
            'query': {
                'action': 'change_page',
                'url': _json(ref),
                'current': str(page),
                'total': str(total_pages),
            },
        })

    item['cm'] = cm
    return item


def _article_item(article):

    item = {
        'title': article['title'],
        # The article archives carry no video on the rebuilt site, so they are
        # listed for information only rather than as playable items.
        'action': None,
        'isFolder': 'False',
        'isPlayable': 'False',
    }

    if article.get('image'):
        item['image'] = article['image']
        item['fanart'] = article['image']

    return item


def _cy_show_item(show):

    item = {
        'title': show['title'],
        'action': 'listing',
        'url': _ref(kind='cy_episodes', base=show['url'], title=show['title']),
        'isFolder': 'True',
    }

    if show.get('image'):
        item['image'] = show['image']
        item['fanart'] = show['image']

    item['cm'] = _browseable(item)

    return item


def _render(built):

    directory.builder(built, content='videos', cacheToDisc=False)


# ---------------------------------------------------------------------------
# Playback
# ---------------------------------------------------------------------------

@urldispatcher.register('play_trailer', ['url'])
def play_trailer(url):
    """
    Searches YouTube for movie trailers using scrapetube, displays up to 3 results
    in a select dialog, and plays the chosen trailer.
    """
    try:
        data = json.loads(url)
        title = data.get('title', '')
    except Exception:
        title = url

    if not title:
        kodi.infoDialog(i18n(30068))
        return

    try:
        from scrapetube import wrapper
        query = '{0} trailer'.format(title)
        results = wrapper.list_search(
            query, limit=3, add_prefix=True, add_url=wrapper.YT_PREFIX
        )
    except Exception as error:
        kodi.infoDialog('{0}: {1}'.format(i18n(30034), error))
        return

    if not results:
        kodi.infoDialog(i18n(30068))
        return

    labels = []
    for r in results:
        r_title = r.get('title') or title
        dur = r.get('duration') or 0
        if dur > 0:
            m, s = divmod(dur, 60)
            dur_str = ' [{0}:{1:02d}]'.format(m, s)
        else:
            dur_str = ''
        labels.append('{0}{1}'.format(r_title, dur_str))

    heading = '{0} - {1}'.format(title, i18n(30067))
    chosen = kodi.selectDialog(labels, heading=heading)

    if chosen == -1:
        return

    selected_video = results[chosen]
    _resolve(selected_video['url'])


@urldispatcher.register('play', ['url'])
def play(url):

    _resolve(url)


@urldispatcher.register('live')
def live():
    """Live is a single playable entry delegated to PluginsGR/ResolveURL."""

    live_url = CY_LIVE_PAGE if _region() == REGION_CY else GR_LIVE_PAGE
    _resolve(live_url)


def _resolve(url):

    try:
        stream, subtitles = player.resolve(url)
    except Exception as error:
        kodi.infoDialog('{0}: {1}'.format(i18n(30034), error))
        return

    if subtitles:
        # Kodi reads external subtitles appended to the stream url, and its
        # <path>|<url>|<lang>|<name> syntax expects exactly three parts.
        stream = '{}|{}|{}'.format(
            stream, subtitles[0]['url'], subtitles[0].get('lang') or 'Greek'
        )

    _play(stream)


def _play(stream):

    path = stream.split('|')[0]
    hls = '.m3u8' in path
    dash = '.mpd' in path

    directory.resolve(
        stream,
        dash=hls or dash,
        manifest_type='hls' if hls else ('mpd' if dash else None),
        mimetype='application/vnd.apple.mpegurl' if hls else ('application/xml+dash' if dash else None),
    )


# ---------------------------------------------------------------------------
# Bookmarks / misc
# ---------------------------------------------------------------------------

@urldispatcher.register('bookmarks')
def bookmarks_list():

    items = bookmarks.get(path=bookmarks_file()) or []

    if not items:
        directory.builder(_empty(i18n(30009)), content='videos')
        return

    for item in items:
        # Bookmarks were stored from a listing, so restore the playability
        # flags Kodi reads when the container is rebuilt.
        action = item.get('action') or 'play'
        item.update({'action': action, 'isFolder': 'False', 'isPlayable': 'True'})
        del_item = dict((k, v) for k, v in iteritems(item) if k not in ('next', 'cm'))
        del_item['delbookmark'] = del_item.get('url')
        item['cm'] = [{
            'title': 30502,
            'query': {'action': 'deleteBookmark', 'url': _json(del_item)},
        }]

    kodi.setsortmethod('title')

    directory.builder(items, content='videos')


@urldispatcher.register('go_to_root')
def go_to_root():
    directory.run_builtin(action='root', path_history='replace')
