# -*- coding: utf-8 -*-

'''
    Alpha Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENCES/GPL-3.0-only for more information.
'''

BASE_GR = 'https://www.alphatv.gr'
BASE_CY = 'https://www.alphacyprus.com.cy'

REGION_GR = 'GR'
REGION_CY = 'CY'

REGIONS = (
    (REGION_GR, 30004),
    (REGION_CY, 30005),
)


def bookmarks_file(region=None):
    from tulip import kodi
    import os

    if not region:
        try:
            region = kodi.setting('region')
        except Exception:
            region = ''

    if region not in (REGION_GR, REGION_CY):
        region = REGION_GR

    return os.path.join(kodi.dataPath, 'bookmarks_{0}.db'.format(region))


# ---------------------------------------------------------------------------
# GR (alphatv.gr)
#
# The site was rebuilt on WordPress. Every Isobar ajax component the add-on
# used to talk to (/ajax/Isobar.AlphaTv.Components.*) now returns 404 and the
# REST API is disabled outright ("No routes registered"), so the indexers read
# the rendered theme pages. For the shows/series catalogue the Yoast sitemaps
# are used instead: they are the only complete, paginated-free list, while the
# landing carousels only carry the current line-up.
# ---------------------------------------------------------------------------

GR_LIVE_PAGE = BASE_GR + '/live/'

GR_SHOWS_PAGE = BASE_GR + '/shows/'
GR_SERIES_PAGE = BASE_GR + '/series/'

GR_SHOW_SITEMAP = BASE_GR + '/show-sitemap.xml'
GR_SERIES_SITEMAP = BASE_GR + '/series-sitemap.xml'

# A show's episodes live under /show/<slug>/episodes/, a series' under
# /series/<slug>/episodes/. WordPress paginates with /paged/<n>/ (1-indexed),
# filters a series by season and orders ascending with ?order=asc.
GR_EPISODES = '{base}/episodes/'
GR_EPISODES_PAGE = '{base}/episodes/paged/{page}/'

# News bulletins (the playable news section), 608 items and counting.
GR_BROADCASTS_PAGE = BASE_GR + '/newscast/alpha-news/broadcasts/'
GR_BROADCASTS_PAGED = GR_BROADCASTS_PAGE + 'paged/{page}/'

# The remaining news sections are plain article archives with no video on the
# new site; they are listed for information only.
GR_NEWS_SECTIONS = (
    ('politika', 30040),
    ('oikonomia', 30041),
    ('athlitika', 30042),
    ('kosmos', 30043),
    ('koinonia', 30044),
    ('politismos', 30045),
    ('ugeia', 30046),
    ('tech', 30047),
    ('o-alpha', 30048),
    ('prosvasimotita', 30049),
)

GR_NEWS_PAGE = BASE_GR + '/{section}/'
GR_NEWS_PAGED = BASE_GR + '/{section}/page/{page}/'

GR_MOVIES_PAGE = BASE_GR + '/movies/'
GR_MOVIES_PAGED = BASE_GR + '/movies/page/{page}/'

# ---------------------------------------------------------------------------
# CY (alphacyprus.com.cy)
#
# Still Drupal, but the views/ajax endpoints the add-on used to post to are
# gone too. The same content is rendered on plain pages and Drupal paginates
# 0-indexed with ?page=<n>.
# ---------------------------------------------------------------------------

CY_LIVE_PAGE = BASE_CY + '/live'

CY_CATEGORIES = (
    ('all', 30052),
    ('ellinikes-seires', 30050),
    ('entertainment', 30016),
    ('informative', 30015),
    ('news', 30011),
    ('guests', 30064),
    ('cooking', 30065),
)

CY_CATEGORY_PAGE = BASE_CY + '/webtv/{category}?page={page}'

# A show's episodes live under /shows/<category>/<slug>/webtv.
CY_EPISODES_PAGE = '{base}/webtv?page={page}'

CY_MOVIES_PAGE = BASE_CY + '/movies/all?page={page}'

# ---------------------------------------------------------------------------
# Playback
#
# Stream resolution is delegated to ResolveURL / PluginsGR's AlphaGRResolver,
# which already targets the rebuilt site (live m3u8, episode/broadcast mp4).
# ---------------------------------------------------------------------------

PLUGINSGR_ID = 'script.module.resolveurl.pluginsgr'
PLUGINS_PATH = 'special://home/addons/{0}/resources/plugins/'.format(PLUGINSGR_ID)
