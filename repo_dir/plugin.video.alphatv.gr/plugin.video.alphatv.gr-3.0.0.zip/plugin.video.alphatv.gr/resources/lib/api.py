# -*- coding: utf-8 -*-

'''
    Alpha Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENCES/GPL-3.0-only for more information.
'''

import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from html import unescape

from . import constants as c

try:
    from tulip import kodi
except ImportError:  # pragma: no cover - only when run outside Kodi
    kodi = None

try:
    from netclient import Net

    _net = Net()
except ImportError:  # pragma: no cover - only when run outside Kodi
    _net = None


USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36')

TAG_RE = re.compile(r'<[^>]+>')
WS_RE = re.compile(r'\s+')


# ---------------------------------------------------------------------------
# HTTP plumbing
# ---------------------------------------------------------------------------

def fetch(url, timeout=30, retries=2):
    """
    The site rate limits bursts with a 429, which happens when a user pages
    through a long archive quickly. Back off and try again rather than
    surfacing an empty listing.
    """

    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'el-GR,el;q=0.9,en;q=0.8',
    }

    for attempt in range(retries + 1):

        try:
            if _net is not None:
                response = _net.http_GET(url, headers=headers, timeout=timeout)
                # netclient falls back to ascii when a response carries no
                # charset, which mangles the Greek titles, so always decode
                # the raw bytes.
                return response.nodecode(True).content.decode('utf-8', 'replace')

            import urllib.request

            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.read().decode('utf-8', 'replace')

        except Exception as error:
            if not _throttled(error) or attempt == retries:
                raise

            time.sleep(3 * (attempt + 1))


def _throttled(error):
    """True for the HTTP 429 the site answers bursts with."""

    return getattr(error, 'code', None) == 429 or '429' in str(error)


def _clean(value):
    """Unescapes entities and flattens the whitespace of a scraped string."""

    if not value:
        return ''

    return WS_RE.sub(' ', unescape(value)).strip()


def _clean_multiline(raw_html):
    """Strips HTML tags preserving paragraph line breaks and drops site UI text."""

    if not raw_html:
        return ''

    text = re.sub(r'</p>|<br\s*/?>', '\n', raw_html)
    text = TAG_RE.sub('', text)
    lines = [_clean(l) for l in text.split('\n')]
    clean_lines = [l for l in lines if l and l not in ('ΔΙΑΒΑΣΤΕ ΠΕΡΙΣΣΟΤΕΡΑ', 'ΛΙΓΟΤΕΡΑ')]
    return '\n'.join(clean_lines)


def _setting(name, default=''):

    try:
        return kodi.setting(name)
    except Exception:
        return default


# ---------------------------------------------------------------------------
# Pagination
#
# WordPress and Drupal both render a full pager; the add-on only ever needs to
# know whether a previous/next page exists, since navigation is exposed as
# "Previous page" / "Next page" items rather than a page number input.
# ---------------------------------------------------------------------------

def _wp_pager(html, current_page=1):

    has_prev = bool(re.search(r'class="(?:prev|previous)\s+page-numbers"', html))
    has_next = bool(re.search(r'class="next\s+page-numbers"', html))

    nums = [int(m.group(1)) for m in re.finditer(
        r'class=[\'"][^\'"]*page-numbers[^\'"]*[\'"][^>]*>\s*(\d+)\s*<', html)]
    if nums:
        total = max(nums)
    elif has_next:
        total = current_page + 1
    else:
        total = current_page

    return has_prev, has_next, max(total, current_page)


def _cy_pager(html, current_page=0):

    has_prev = bool(re.search(r'class="pager__item pager__item--previous"', html))
    has_next = bool(re.search(r'class="pager__item pager__item--next"', html))

    nums = [int(p.group(1)) for p in re.finditer(r'[\?&]page=(\d+)', html)]
    if nums:
        total = max(nums) + 1
    elif has_next:
        total = current_page + 2
    else:
        total = current_page + 1

    return has_prev, has_next, max(total, current_page + 1)


def _gr_cards(html, url_pattern):
    """
    Parses the theme's ``.card`` grid, which backs episodes, series episodes
    and news bulletins alike:

        <div class="card ... card__show_episode">
          <figure class="card__image">
            <a href="URL" title="TITLE">
              <picture>...<img data-src="IMAGE" alt="TITLE">
    """

    cards = []
    card_chunks = re.split(r'<div class="card\s+', html)

    for chunk in card_chunks[1:]:
        match = re.search(
            r'<a href="(?P<url>{0})" title="(?P<title>[^"]*)"'.format(url_pattern), chunk)
        if not match:
            continue

        image = re.search(r'data-src="([^" ]+)"', chunk) or \
            re.search(r'srcset="([^" ,]+)', chunk)

        lead = re.search(r'class="card__lead">\s*(.*?)\s*</div>', chunk, re.S)
        caption = re.search(r'class="card__caption[^"]*">\s*<span>([^<]+)</span>', chunk)

        plot = ''
        if caption:
            plot = _clean(caption.group(1))
        elif lead:
            plot = _clean(TAG_RE.sub('', lead.group(1)))

        cards.append({
            'title': _clean(match.group('title')),
            'url': match.group('url'),
            'image': unescape(image.group(1)) if image else '',
            'plot': plot,
        })

    return _dedupe(cards)


def _cy_cards(html):
    """
    Parses the Drupal ``.box`` grid, used for both show and episode listings.
    The title sits in ``box__title`` on episode archives and in
    ``box__overlay-title`` on the show carousels:

        <div class="box__image"><a href="URL"><img src="IMAGE"></a>
        <div class="box__title"><a href="URL">TITLE</a></div>
    """

    cards = []
    seen = set()

    for match in re.finditer(
            r'<div class="box__(?:overlay-)?title">\s*<a href="(?P<url>/shows/[^"]+)"'
            r'[^>]*>\s*(?:<span[^>]*>)?(?P<title>.*?)(?:</span>)?\s*</a>', html, re.S):
        url = match.group('url')

        if url in seen:
            continue

        seen.add(url)

        title = _clean(TAG_RE.sub('', match.group('title')))
        sub_m = re.search(r'<div class="box__overlay-subtitle">\s*(?P<subtitle>.*?)\s*</div>',
                          html[match.end():match.end() + 250], re.S)
        if sub_m:
            sub = _clean(TAG_RE.sub('', sub_m.group('subtitle')))
            if sub and not title.startswith(sub):
                title = '{0} - {1}'.format(sub, title)

        window = html[max(0, match.start() - 900):match.start()]

        image = re.search(r'<img[^>]+src="([^"]+)"', window)

        cards.append({
            'title': title,
            'url': c.BASE_CY + url,
            'image': unescape(image.group(1)) if image else '',
        })

    return cards


def _dedupe(cards):

    out = []
    seen = set()

    for card in cards:
        if not card['url'] or card['url'] in seen or not card['title']:
            continue

        seen.add(card['url'])
        out.append(card)

    return out


# ---------------------------------------------------------------------------
# GR catalogue
# ---------------------------------------------------------------------------

def _sitemap(sitemap_url, landing_url, path):

    """
    Merges two sources into a complete catalogue:

    * the Yoast sitemap, which lists every show/series but carries no artwork
      nor titles, sorted by lastmod so the newest entries come first;
    * the landing carousel, which carries the title and the cover image for the
      current line-up but only for part of it.
    """

    entries = {}
    order = []

    try:
        xml = fetch(sitemap_url)
    except Exception:
        xml = ''

    for block in re.findall(r'<url>(.*?)</url>', xml, re.S):
        url = re.search(r'<loc>([^<]+)</loc>', block)
        lastmod = re.search(r'<lastmod>([^<]+)</lastmod>', block)

        if not url:
            continue

        slug = _slug(url.group(1), path)

        if not slug:
            continue

        entries[slug] = {
            'slug': slug,
            'title': slug,
            'url': '{0}/{1}/{2}/'.format(c.BASE_GR, path.rstrip('/'), slug),
            'image': '',
            'lastmod': lastmod.group(1) if lastmod else '',
        }
        order.append(slug)

    try:
        landing = fetch(landing_url)
    except Exception:
        landing = ''

    pattern = r'https://www\.alphatv\.gr/{0}/[a-z0-9-]+/'.format(path)

    for match in re.finditer(
            r'<a href="(?P<url>{0})" title="(?P<title>[^"]*)"'.format(pattern), landing):
        slug = _slug(match.group('url'), path)

        if slug not in entries:
            entries[slug] = {
                'slug': slug,
                'title': slug,
                'url': match.group('url'),
                'image': '',
                'lastmod': '',
            }
            order.append(slug)

        entries[slug]['title'] = _clean(match.group('title')) or slug
        entries[slug]['url'] = match.group('url')

    for card in _gr_cards(landing, pattern):
        entry = entries.get(_slug(card['url'], path))

        if entry is not None:
            entry['image'] = card['image'] or entry['image']

    for entry in entries.values():
        if entry['title'] == entry['slug'] or not entry['image']:
            title, image = _page_meta(entry['url'])
            entry['title'] = title or entry['title']
            entry['image'] = image or entry['image']

    return [entries[slug] for slug in order]


def _page_meta(url):
    """
    The landing carousel only covers the current line-up, so the longer tail of
    the sitemap is still slug-only and imageless. Their own page carries the
    real title and cover; the result is cached together with the catalogue, so
    this costs one request each and only for the entries that need it.
    """

    try:
        html = fetch(url)
    except Exception:
        return '', ''

    match = re.search(r'<meta property="og:title" content="([^"]+)"', html) or \
        re.search(r'<title>(.*?)</title>', html, re.S)

    # The theme appends the site name, e.g. "Σειρά: 10η Εντολή | AlphaTV".
    title = _clean(match.group(1)).split('|')[0].strip() if match else ''

    image = re.search(r'<meta property="og:image" content="([^"]+)"', html)

    return title, unescape(image.group(1)) if image else ''


def _slug(url, path):

    match = re.search(r'/{0}/([a-z0-9-]+)/?$'.format(re.escape(path)), url or '')

    return match.group(1) if match else ''


def shows():

    return _sitemap(c.GR_SHOW_SITEMAP, c.GR_SHOWS_PAGE, 'show')


def series():

    return _sitemap(c.GR_SERIES_SITEMAP, c.GR_SERIES_PAGE, 'series')


def seasons(series_url):

    """
    The season filter sits above the episode grid, not on the series page
    itself, so it is read from the first page of the episode archive.
    """

    html = fetch(c.GR_EPISODES.format(base=series_url.rstrip('/')))

    seasons = []
    seen = set()

    for match in re.finditer(
            r'<a[^>]+href="([^"]*[?&]season=season-(\d+))"[^>]*>(.*?)</a>', html, re.S):
        number = int(match.group(2))

        if number in seen:
            continue

        seen.add(number)
        seasons.append({
            'title': _clean(TAG_RE.sub('', match.group(3))) or 'ΣΕΖΟΝ {0}'.format(number),
            # Kept numeric so 10 sorts after 9 rather than after 1.
            'season': number,
        })

    is_reverse = _setting('reverse') != 'false'
    return sorted(seasons, key=lambda season: season['season'], reverse=is_reverse)


def episodes(base_url, page=1, season=None):
    """Returns (items, has_previous, has_next)."""

    base = base_url.rstrip('/')

    if page and page > 1:
        url = c.GR_EPISODES_PAGE.format(base=base, page=page)
    else:
        url = c.GR_EPISODES.format(base=base)

    query = []

    if season:
        query.append('season=season-{0}'.format(season))

    # The site's own toggle, rather than reversing the parsed list, keeps the
    # pagination in sync with what is actually on screen.
    if _setting('reverse') == 'true':
        query.append('order=asc')

    if query:
        url = '{0}?{1}'.format(url, '&'.join(query))

    html = fetch(url)

    pattern = r'https://www\.alphatv\.gr/(?:show|series)/[a-z0-9-]+/' \
              r'(?:show-)?episode/\d+[^"]*'

    items = _gr_cards(html, pattern)
    has_previous, has_next, total_pages = _wp_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


def broadcasts(page=1):
    """News bulletins, which are the only playable news content on the new site."""

    url = c.GR_BROADCASTS_PAGED.format(page=page) if page and page > 1 \
        else c.GR_BROADCASTS_PAGE

    html = fetch(url)

    pattern = r'https://www\.alphatv\.gr/newscast/[a-z0-9-]+/broadcast/\d+[^"]*'

    items = _gr_cards(html, pattern)
    has_previous, has_next, total_pages = _wp_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


def news(section, page=1):
    """Article archives. These carry no video on the rebuilt site."""

    url = c.GR_NEWS_PAGED.format(section=section, page=page) if page and page > 1 \
        else c.GR_NEWS_PAGE.format(section=section)

    html = fetch(url)

    pattern = r'https://www\.alphatv\.gr/{0}/[a-z0-9-]+/'.format(re.escape(section))

    items = []
    seen = set()

    for match in re.finditer(
            r'<article class="article_card.*?</article>', html, re.S):
        block = match.group(0)

        link = re.search(r'<a href="(?P<url>{0})" title="(?P<title>[^"]*)"'.format(pattern),
                         block)

        if not link or link.group('url') in seen:
            continue

        seen.add(link.group('url'))

        image = re.search(r'data-src="([^"]+)"', block)

        items.append({
            'title': _clean(link.group('title')),
            'url': link.group('url'),
            'image': unescape(image.group(1)) if image else '',
        })

    has_previous, has_next, total_pages = _wp_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


def _fetch_gr_movie_detail(card):
    """Fetches the movie page to extract structured metatags and synopsis."""
    try:
        html = fetch(card['url'], timeout=10)
        m = re.search(r'<div class="single_movie__content">(.*?)</div>\s*</div>', html, re.S)
        if m:
            text = re.sub(r'</p>|<br\s*/?>', '\n', m.group(1))
            text = TAG_RE.sub('', text)
            lines = [_clean(l) for l in text.split('\n') if l.strip()]

            synopsis_lines = []
            for line in lines:
                if line in ('ΔΙΑΒΑΣΤΕ ΠΕΡΙΣΣΟΤΕΡΑ', 'ΛΙΓΟΤΕΡΑ'):
                    continue
                if line.startswith('Σκηνοθεσία:'):
                    directors = [_clean(d) for d in line[len('Σκηνοθεσία:'):].split(',') if d.strip()]
                    if directors:
                        card['director'] = directors
                elif line.startswith(('Σενάριο:', 'Σενάριο – Σκηνοθεσία:', 'Σενάριο - Σκηνοθεσία:')):
                    prefix = line.split(':')[0] + ':'
                    writers = [_clean(w) for w in line[len(prefix):].split(',') if w.strip()]
                    if writers:
                        card['writer'] = writers
                    if 'Σκηνοθεσία' in prefix and 'director' not in card:
                        card['director'] = writers
                elif line.startswith('Ηθοποιοί:'):
                    actors = [_clean(a) for a in line[len('Ηθοποιοί:'):].split(',') if a.strip()]
                    if actors:
                        card['cast'] = actors
                elif line.startswith('Διάρκεια:'):
                    dur_m = re.search(r'(\d+)', line)
                    if dur_m:
                        card['duration'] = int(dur_m.group(1)) * 60
                elif line.startswith('Σήμανση:'):
                    card['mpaa'] = line[len('Σήμανση:'):].strip()
                elif 'παραγωγής' in line:
                    year_m = re.search(r'\b(19\d\d|20\d\d)\b', line)
                    if year_m:
                        card['year'] = int(year_m.group(1))
                    card['tagline'] = line
                else:
                    synopsis_lines.append(line)

            if synopsis_lines:
                card['plot'] = '\n\n'.join(synopsis_lines)
    except Exception:
        pass
    return card


def movies(page=1):
    """Returns (items, has_previous, has_next, total_pages) for GR movies."""

    url = c.GR_MOVIES_PAGED.format(page=page) if page and page > 1 else c.GR_MOVIES_PAGE

    html = fetch(url)

    pattern = r'https://www\.alphatv\.gr/movie/[a-z0-9-]+/'

    items = _gr_cards(html, pattern)

    if items:
        with ThreadPoolExecutor(max_workers=min(len(items), 6)) as executor:
            items = list(executor.map(_fetch_gr_movie_detail, items))

    has_previous, has_next, total_pages = _wp_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


# ---------------------------------------------------------------------------
# CY
# ---------------------------------------------------------------------------

def cy_shows(category, page=0):
    """Returns (items, has_previous, has_next, total_pages). Drupal paginates 0-indexed."""

    url = c.CY_CATEGORY_PAGE.format(category=category, page=page)

    html = fetch(url)

    items = _cy_cards(html)
    has_previous, has_next, total_pages = _cy_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


def cy_episodes(base_url, page=0):
    """Returns (items, has_previous, has_next, total_pages)."""

    url = c.CY_EPISODES_PAGE.format(base=base_url.rstrip('/'), page=page)

    html = fetch(url)

    items = _cy_cards(html)
    has_previous, has_next, total_pages = _cy_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages


def cy_live_url():
    """
    The live page inlines a signed cloudskep playlist. The signature embeds a
    server timestamp and is regenerated per request, so it must be read fresh
    on every playback.
    """

    html = fetch(c.CY_LIVE_PAGE)

    match = re.search(r'hls: [\'"](.+?)[\'"]', html)

    return match.group(1) if match else ''


def _fetch_cy_movie_detail(card):
    """Fetches the movie page to extract structured metatags and synopsis."""
    try:
        raw = fetch(card['url'], timeout=10)
        details_m = re.search(
            r'<div class="content-body__details[^"]*">(.*?)</div>\s*<div class="content-body__content',
            raw, re.S)
        if details_m:
            fields = re.split(r'<div class="[^"]*f-field[^"]*">', details_m.group(1))
            for f in fields[1:]:
                label_m = re.search(r'<label>\s*([^<]+)\s*</label>', f)
                label = label_m.group(1).strip() if label_m else ''

                val_m = re.search(r'</label>\s*<div>(.*)</div>\s*</div>', f, re.S)
                if not val_m:
                    val_m = re.search(r'<div>(.*)</div>\s*</div>', f, re.S)
                if not val_m:
                    continue

                val = val_m.group(1)
                divs = re.findall(r'<div[^>]*>\s*([^<]+)\s*</div>', val)
                if divs:
                    items = [_clean(d) for d in divs if d.strip()]
                else:
                    items = [_clean(s) for s in TAG_RE.sub('', val).split(',') if s.strip()]

                if not items:
                    continue

                if label == 'ΕΙΔΟΣ':
                    card['genre'] = items
                elif label == 'Σενάριο':
                    card['writer'] = items
                elif label == 'Σκηνοθέτης':
                    card['director'] = items
                elif label == 'Ηθοποιοί':
                    card['cast'] = items
                elif 'Διαρκεια' in label or 'Διάρκεια' in label:
                    dur_m = re.search(r'(\d+)', items[0])
                    if dur_m:
                        card['duration'] = int(dur_m.group(1)) * 60

        desc_m = re.search(
            r'<div class="content-body__description[^"]*">.*?<div>\s*(.*?)\s*</div>\s*</div>',
            raw, re.S)
        if desc_m:
            desc = _clean_multiline(desc_m.group(1))
            if desc:
                card['plot'] = desc
    except Exception:
        pass
    return card


def cy_movies(page=0):
    """Returns (items, has_previous, has_next, total_pages) for CY movies. Drupal paginates 0-indexed."""

    url = c.CY_MOVIES_PAGE.format(page=page)

    html = fetch(url)

    items = []
    seen = set()
    chunks = re.split(r'<div[^>]*class=[\'"][^\'"]*?\bbox\b[^\'"]*?[\'"]', html)

    for chunk in chunks[1:]:
        match = re.search(
            r'<div class="box__title">\s*<a href="(?P<url>/movies/[^\'"]+)">(?P<title>[^<]+)</a>', chunk)
        if not match:
            continue

        url_path = match.group('url')
        if url_path in ('/movies/all', '/movies/greek', '/movies/box-office') or url_path.startswith('/movies/categories/'):
            continue

        if url_path in seen:
            continue

        seen.add(url_path)

        image = re.search(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', chunk)
        cat = re.search(r'<div class="box__category">\s*([^<]+)\s*</div>', chunk)

        items.append({
            'title': _clean(match.group('title')),
            'url': c.BASE_CY + url_path,
            'image': unescape(image.group(1)) if image else '',
            'plot': _clean(cat.group(1)) if cat else '',
        })

    if items:
        with ThreadPoolExecutor(max_workers=min(len(items), 6)) as executor:
            items = list(executor.map(_fetch_cy_movie_detail, items))

    has_previous, has_next, total_pages = _cy_pager(html, current_page=page)

    return items, has_previous, has_next, total_pages
