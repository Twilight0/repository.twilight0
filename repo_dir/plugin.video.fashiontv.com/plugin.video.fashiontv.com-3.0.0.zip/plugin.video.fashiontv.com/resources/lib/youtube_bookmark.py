# -*- coding: utf-8 -*-

'''
    Fashion TV Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import json
from tulip import bookmarks, kodi

url = {
    'title': kodi.get_info_label('ListItem.Label'), 'image': kodi.get_info_label('ListItem.Art(thumb)'),
    'fanart': kodi.get_info_label('ListItem.Art(fanart)'), 'plot': kodi.get_info_label('ListItem.Plot'),
    'bookmark': kodi.get_info_label('ListItem.FolderPath'), 'url': kodi.get_info_label('ListItem.FolderPath')
}

if 'playlist' in url['url']:
    url.update({'action': 'youtube' if 'plugin.video.youtube' in url['url'] else 'newpipe', 'isFolder': False, 'isPlayable': False})
elif 'plugin.video.newpipe' in url['url']:
    url.update({'action': 'newpipe', 'isFolder': False, 'isPlayable': False})
else:
    url.update({'action': 'play', 'isFolder': False})

path = kodi.transPath('special://profile/addon_data/plugin.video.fashiontv.com/bookmarks.db')

bookmarks.add(json.dumps(url), path)
