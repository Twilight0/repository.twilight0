# -*- coding: utf-8 -*-

'''
    Fashion TV Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import json
from base64 import b64decode
from zlib import decompress
from tulip import kodi, bookmarks
from urldispatcher import urldispatcher
from .constants import scramble, reset_cache


def keys_registration():

    try:
        from youtube_registration import register_api_keys
    except ImportError:
        return

    try:
        keys = json.loads(decompress(b64decode(scramble)))
        register_api_keys(kodi.addonInfo('id'), keys['api_key'], keys['id'], keys['secret'])
    except Exception:
        pass


@urldispatcher.register('clear_cache')
def clear_cache():

    reset_cache()
    kodi.infoDialog(kodi.i18n(30002))


@urldispatcher.register('addBookmark', ['url'])
def addBookmark(url):

    bookmarks.add(url)


@urldispatcher.register('deleteBookmark', ['url'])
def deleteBookmark(url):

    bookmarks.delete(url)
