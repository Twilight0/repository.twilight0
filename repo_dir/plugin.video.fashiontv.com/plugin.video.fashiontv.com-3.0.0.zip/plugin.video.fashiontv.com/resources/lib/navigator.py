# -*- coding: utf-8 -*-

'''
    Fashion TV Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import json
import re
from urllib.parse import urlparse, parse_qs, urljoin, urlencode

from netclient import Net
from tulip import directory, kodi, bookmarks as bms
from tulip.log import log
from urldispatcher import urldispatcher

from .constants import (
    main_link, main_json, IPTV_ORG_LIFESTYLE_M3U,
    fashion_tv_yt_channel, ftv_yt_channel, ftv_hot_yt_channel,
    ftv_parties_yt_channel, ftv_asia_yt_channel, ftv_news_channel,
    cache_function
)
from .utils import keys_registration


def _scrape_live_official():

    try:
        response = Net().http_GET(main_link)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', content)
        if m:
            data = json.loads(m.group(1))
            hc = data.get('props', {}).get('pageProps', {}).get('homeContainer', {})
            first = hc.get('firstVideo') or {}
            if first and first.get('streamURL'):
                return {
                    'id': str(first.get('id', 'live_paris')),
                    'title': first.get('title', "FashionTV Paris L'Original"),
                    'plot': first.get('description', 'FashionTV live broadcast in 1080p FHD'),
                    'image': first.get('thumbnail') or kodi.addonmedia('live.jpg'),
                    'fanart': first.get('thumbnail') or kodi.addonInfo('fanart'),
                    'url': first.get('streamURL', ''),
                    'is_live': True
                }
    except Exception as e:
        log('Fashion TV: failed to scrape live stream from website: {0}'.format(e))

    try:
        response = Net().http_GET(main_json)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        _json = json.loads(content)
        content_dict = _json.get('content', {})
        for k, c in content_dict.items():
            if c.get('is_live_streaming') and c.get('streamURL'):
                return {
                    'id': str(c.get('id', k)),
                    'title': c.get('title', "FashionTV Paris L'Original"),
                    'plot': c.get('description', 'FashionTV live broadcast in 1080p FHD'),
                    'image': c.get('thumbnail') or c.get('thumbnail_playlist') or kodi.addonmedia('live.jpg'),
                    'fanart': c.get('thumbnail') or kodi.addonInfo('fanart'),
                    'url': c.get('streamURL', ''),
                    'is_live': True
                }
    except Exception as e:
        log('Fashion TV: failed to scrape live stream from feed: {0}'.format(e))

    return None


def _fetch_website():

    try:
        response = Net().http_GET(main_link)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', content)
        if not m:
            return None

        data = json.loads(m.group(1))
        hc = data.get('props', {}).get('pageProps', {}).get('homeContainer', {})

        first = hc.get('firstVideo') or {}
        live_item = None
        if first and first.get('streamURL'):
            live_item = {
                'id': str(first.get('id', 'live_paris')),
                'title': first.get('title', "FashionTV Paris L'Original"),
                'plot': first.get('description', ''),
                'image': first.get('thumbnail', ''),
                'fanart': first.get('thumbnail', ''),
                'url': first.get('streamURL', ''),
                'is_live': True
            }

        categories = []
        all_videos = {}

        for c in hc.get('content', []):
            cid = str(c.get('entity_id', ''))
            ctitle = c.get('title', '')
            vids = []
            for v in c.get('videos', []):
                vid_id = str(v.get('id', ''))
                vid = {
                    'id': vid_id,
                    'title': v.get('title', ''),
                    'plot': v.get('description', ''),
                    'image': v.get('thumbnail', ''),
                    'fanart': v.get('thumbnail', ''),
                    'url': v.get('streamURL', ''),
                    'is_live': v.get('is_live_streaming', False),
                    'duration': v.get('videoDuration')
                }
                vids.append(vid)
                all_videos[vid_id] = vid
            if vids:
                categories.append({
                    'id': cid,
                    'title': ctitle,
                    'videos': vids
                })

        return live_item, categories, all_videos

    except Exception as e:
        log('Fashion TV: failed to fetch website: {0}'.format(e))
        return None


def _fetch_feed():

    try:
        response = Net().http_GET(main_json)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        _json = json.loads(content)
        pls = list(_json.get('playlists', {}).values())
        content_dict = _json.get('content', {})

        all_videos = {}
        live_item = None

        for k, c in content_dict.items():
            vid = str(c.get('id', k))
            is_live = bool(c.get('is_live_streaming', False))
            vid_data = {
                'id': vid,
                'title': c.get('title', ''),
                'plot': c.get('description', ''),
                'image': c.get('thumbnail_playlist') or c.get('thumbnail', ''),
                'fanart': c.get('thumbnail', ''),
                'duration': c.get('videoDuration'),
                'is_live': is_live,
                'url': c.get('streamURL', '')
            }
            all_videos[vid] = vid_data
            if is_live and not live_item:
                live_item = vid_data

        categories = []
        country_highlights = []

        for p in pls:
            p_id = str(p.get('entity_id', ''))
            name = p.get('name', '')
            item_ids = [str(x) for x in p.get('itemIds', [])]
            vids = [all_videos[i] for i in item_ids if i in all_videos]
            if not vids:
                continue
            p_data = {'id': p_id, 'title': name, 'videos': vids}
            if name.startswith('Highlights of '):
                country_highlights.append(p_data)
            else:
                categories.append(p_data)

        return live_item, categories, country_highlights, all_videos

    except Exception as e:
        log('Fashion TV: failed to fetch castify feed: {0}'.format(e))
        return None


@cache_function(60)
def loader():

    site_result = _fetch_website()
    feed_result = _fetch_feed()

    live_item = None
    categories = []
    country_highlights = []
    all_videos = {}

    if feed_result:
        f_live, f_cats, f_countries, f_videos = feed_result
        live_item = f_live
        categories = f_cats
        country_highlights = f_countries
        all_videos.update(f_videos)

    if site_result:
        s_live, s_cats, s_videos = site_result
        if s_live:
            live_item = s_live
        if s_cats:
            categories = s_cats
        all_videos.update(s_videos)

    return live_item, categories, country_highlights, all_videos


@urldispatcher.register('root')
def root():

    self_list = [
        {
            'title': kodi.i18n(30001),
            'action': 'main',
            'isFolder': True,
            'icon': kodi.addonInfo('icon'),
            'image': kodi.addonInfo('icon'),
        },
        {
            'title': kodi.i18n(30009),
            'action': 'live',
            'isFolder': True,
            'icon': kodi.addonmedia('live.jpg'),
            'image': kodi.addonmedia('live.jpg'),
        },
        {
            'title': kodi.i18n(30012),
            'action': 'countries',
            'isFolder': True,
            'icon': kodi.addonmedia('highlights.jpg'),
            'image': kodi.addonmedia('highlights.jpg'),
        },
        {
            'title': kodi.i18n(30010),
            'action': 'search',
            'isFolder': True,
            'icon': kodi.addonmedia('search.jpg'),
            'image': kodi.addonmedia('search.jpg'),
        },
        {
            'title': kodi.i18n(30003),
            'action': 'yt_channels',
            'isFolder': True,
            'icon': 'https://yt3.ggpht.com/a/AATXAJxLtsDGDS6pB9XFt_2wIe3UrG9BU3UW7qVscEQgSg=s256',
            'image': 'https://yt3.ggpht.com/a/AATXAJxLtsDGDS6pB9XFt_2wIe3UrG9BU3UW7qVscEQgSg=s256',
        },
        {
            'title': kodi.i18n(30005),
            'action': 'bookmarks',
            'isFolder': True,
            'icon': kodi.addonmedia('bookmarks.jpg'),
            'image': kodi.addonmedia('bookmarks.jpg'),
        }
    ]

    for item in self_list:
        clear_cache = {'title': 30002, 'query': {'action': 'clear_cache'}}
        item.update({'cm': [clear_cache]})

    directory.builder(self_list)


@cache_function(60)
def _fetch_iptv_org():

    channels = []
    try:
        response = Net().http_GET(IPTV_ORG_LIFESTYLE_M3U)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        lines = content.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('#EXTINF'):
                logo_m = re.search(r'tvg-logo="([^"]+)"', line)
                id_m = re.search(r'tvg-id="([^"]+)"', line)
                logo = logo_m.group(1) if logo_m else ''
                tvg_id = id_m.group(1) if id_m else ''
                raw_title = line.split(',')[-1].strip()

                i += 1
                while i < len(lines) and (not lines[i].strip() or lines[i].startswith('#')):
                    i += 1
                if i < len(lines):
                    stream_url = lines[i].strip()
                    low_id = tvg_id.lower()
                    low_title = raw_title.lower()

                    if 'fashiontv' in low_id or 'fashion tv' in low_title or 'codefashion' in low_id or 'globalfashion' in low_id:
                        display_title = raw_title
                        if 'FashionTV.ru' in tvg_id and 'Russia' not in display_title:
                            display_title = 'FashionTV Russia (1080p)'
                        elif 'FashionTV.ua' in tvg_id and 'Ukraine' not in display_title:
                            display_title = 'FashionTV Ukraine (1080p)'

                        channels.append({
                            'id': tvg_id or display_title,
                            'title': display_title,
                            'url': stream_url,
                            'image': logo,
                            'fanart': kodi.addonInfo('fanart'),
                            'plot': '{0} live stream via iptv-org'.format(display_title)
                        })
            i += 1
    except Exception as e:
        log('Fashion TV: failed to fetch iptv-org lifestyle playlist: {0}'.format(e))

    return channels


@urldispatcher.register('live')
def live():

    live_item = _scrape_live_official()
    if not live_item:
        live_item = loader()[0]
    iptv_channels = _fetch_iptv_org() or []

    items = []

    if live_item:
        img = live_item.get('image') or kodi.addonmedia('live.jpg')
        if img == 'live.jpg':
            img = kodi.addonmedia('live.jpg')

        official_item = {
            'title': live_item.get('title', "FashionTV Paris L'Original"),
            'plot': live_item.get('plot', "FashionTV live broadcast in 1080p FHD"),
            'image': img,
            'icon': img,
            'fanart': live_item.get('fanart') or kodi.addonInfo('fanart'),
            'url': live_item.get('url', ''),
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        bookmark = {
            'title': official_item['title'],
            'url': official_item['url'],
            'action': 'play',
            'image': official_item['image'],
            'isFolder': False,
            'isPlayable': True
        }
        official_item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        items.append(official_item)

    for ch in iptv_channels:
        if live_item and "paris l'original" in ch['title'].lower():
            continue

        ch_img = ch.get('image') or kodi.addonmedia('live.jpg')
        item = {
            'title': ch['title'],
            'plot': ch.get('plot', ''),
            'image': ch_img,
            'icon': ch_img,
            'fanart': ch.get('fanart') or kodi.addonInfo('fanart'),
            'url': ch['url'],
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        bookmark = {
            'title': item['title'],
            'url': item['url'],
            'action': 'play',
            'image': item['image'],
            'isFolder': False,
            'isPlayable': True
        }
        item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        items.append(item)

    if not items:
        kodi.infoDialog(kodi.i18n(30011))
        from tulip.init import syshandle
        if syshandle >= 0:
            kodi.directory(syshandle, False)
        return

    directory.builder(items, content='videos')


@urldispatcher.register('main')
def main():

    categories = loader()[1]

    self_list = []
    for cat in categories:
        img = cat['videos'][0]['image'] if cat.get('videos') and cat['videos'][0].get('image') else kodi.addonInfo('icon')
        fan = cat['videos'][0]['fanart'] if cat.get('videos') and cat['videos'][0].get('fanart') else kodi.addonInfo('fanart')
        item = {
            'title': cat['title'],
            'action': 'playlist',
            'query': cat['id'],
            'isFolder': True,
            'icon': img,
            'image': img,
            'fanart': fan
        }
        bookmark = {'title': cat['title'], 'action': 'playlist', 'query': cat['id'], 'isFolder': True, 'image': img, 'fanart': fan}
        item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        self_list.append(item)

    kodi.setsortmethod('none')
    kodi.setsortmethod('title')

    directory.builder(self_list, content='videos')


@urldispatcher.register('countries')
def countries():

    country_pls = loader()[2]

    self_list = []
    for cat in country_pls:
        img = cat['videos'][0]['image'] if cat.get('videos') and cat['videos'][0].get('image') else kodi.addonInfo('icon')
        fan = cat['videos'][0]['fanart'] if cat.get('videos') and cat['videos'][0].get('fanart') else kodi.addonInfo('fanart')
        item = {
            'title': cat['title'],
            'action': 'playlist',
            'query': cat['id'],
            'isFolder': True,
            'icon': img,
            'image': img,
            'fanart': fan
        }
        bookmark = {'title': cat['title'], 'action': 'playlist', 'query': cat['id'], 'isFolder': True, 'image': img, 'fanart': fan}
        item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        self_list.append(item)

    kodi.setsortmethod('title')

    directory.builder(self_list, content='videos')


@cache_function(10080)
def _probe_duration(url):

    if not url or '.m3u8' not in url:
        return None

    try:
        # Extract direct m3u8 URL if wrapped in SSAI/gumgum proxy
        if 'stream_url=' in url:
            qs = parse_qs(urlparse(url).query)
            if 'stream_url' in qs:
                url = qs['stream_url'][0]

        response = Net().http_GET(url)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'replace')

        if '#EXT-X-STREAM-INF' in content:
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    sub_url = urljoin(url, line)
                    sub_resp = Net().http_GET(sub_url)
                    sub_content = sub_resp.content
                    if isinstance(sub_content, bytes):
                        sub_content = sub_content.decode('utf-8', 'replace')
                    extinfs = re.findall(r'#EXTINF:([0-9.]+)', sub_content)
                    if extinfs:
                        return int(round(sum(float(x) for x in extinfs)))
                    break
        else:
            extinfs = re.findall(r'#EXTINF:([0-9.]+)', content)
            if extinfs:
                return int(round(sum(float(x) for x in extinfs)))

    except Exception:
        pass

    return None


@urldispatcher.register('playlist', ['query'])
def playlist(query):

    live_item, categories, country_pls, all_videos = loader()

    videos = []

    all_pls = categories + country_pls
    for p in all_pls:
        if str(p.get('id')) == str(query):
            videos = p.get('videos', [])
            break

    if not videos:
        try:
            parsed = json.loads(query)
            if isinstance(parsed, list):
                videos = [all_videos[str(i)] for i in parsed if str(i) in all_videos]
            elif isinstance(parsed, str) and parsed in all_videos:
                videos = [all_videos[parsed]]
        except (ValueError, TypeError):
            pass

    if not videos and str(query) in all_videos:
        videos = [all_videos[str(query)]]

    items = []
    for v in videos:
        dur = v.get('duration')
        if (not dur or not str(dur).isdigit() or int(dur) <= 0) and v.get('url') and not v.get('is_live'):
            probed = _probe_duration(v['url'])
            if probed:
                dur = probed
                v['duration'] = probed

        img = v.get('image', '')
        fan = v.get('fanart', '')
        item = {
            'title': v.get('title', ''),
            'plot': v.get('plot', ''),
            'image': img,
            'icon': img,
            'fanart': fan,
            'duration': int(dur) if dur and str(dur).isdigit() and int(dur) > 0 else None,
            'url': v.get('url', ''),
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        bookmark = {
            'title': item['title'],
            'url': item['url'],
            'image': item['image'],
            'fanart': item['fanart'],
            'plot': item['plot'],
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        items.append(item)

    kodi.setsortmethod('none')
    kodi.setsortmethod('title')

    directory.builder(items, content='movies')


@urldispatcher.register('search')
def search():

    input_str = kodi.inputDialog()

    if not input_str:
        from tulip.init import syshandle
        if syshandle >= 0:
            kodi.directory(syshandle, False)
        return

    all_videos = loader()[3]
    video_list = list(all_videos.values())

    titles = [v['title'] for v in video_list]

    try:
        from fuzzywuzzy import process
        extracted = process.extract(input_str, titles, limit=30)
        matches = [video_list[titles.index(t)] for t, s in extracted if s >= 60]
    except ImportError:
        q = input_str.lower()
        matches = [v for v in video_list if q in v['title'].lower()]

    if not matches:
        kodi.infoDialog(kodi.i18n(30011))
        from tulip.init import syshandle
        if syshandle >= 0:
            kodi.directory(syshandle, False)
        return

    items = []
    for v in matches:
        dur = v.get('duration')
        if (not dur or not str(dur).isdigit() or int(dur) <= 0) and v.get('url') and not v.get('is_live'):
            probed = _probe_duration(v['url'])
            if probed:
                dur = probed
                v['duration'] = probed

        img = v.get('image', '')
        fan = v.get('fanart', '')
        item = {
            'title': v.get('title', ''),
            'plot': v.get('plot', ''),
            'image': img,
            'icon': img,
            'fanart': fan,
            'duration': int(dur) if dur and str(dur).isdigit() and int(dur) > 0 else None,
            'url': v.get('url', ''),
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        bookmark = {
            'title': item['title'],
            'url': item['url'],
            'image': item['image'],
            'fanart': item['fanart'],
            'plot': item['plot'],
            'action': 'play',
            'isFolder': False,
            'isPlayable': True
        }
        item['cm'] = [{'title': 30004, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]
        items.append(item)

    kodi.setsortmethod('title')
    directory.builder(items, content='movies')


@urldispatcher.register('yt_channels')
def yt_channels():

    self_list = [
        {
            'title': 'Fashion TV',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJxZonaXhogfs_ioQnbxlhR7NpepOecdrBYzbHmOm1k=s256',
            'channel_id': fashion_tv_yt_channel,
            'isFolder': False, 'isPlayable': False
        },
        {
            'title': 'FTV',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJxLtsDGDS6pB9XFt_2wIe3UrG9BU3UW7qVscEQgSg=s256',
            'channel_id': ftv_yt_channel,
            'isFolder': False, 'isPlayable': False
        },
        {
            'title': 'FTV HOT',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJxJIFyHhkMeUbmMEIahbXB8tOe5rQOHMIYjvFh21w=s256',
            'channel_id': ftv_hot_yt_channel,
            'isFolder': False, 'isPlayable': False
        },
        {
            'title': 'FashionTV Parties',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJwiPGuSb3438Ql1kh1Je6YLaWj52skL7MKHgaUJ=s256',
            'channel_id': ftv_parties_yt_channel,
            'isFolder': False, 'isPlayable': False
        },
        {
            'title': 'FashionTV Asia',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJxhBT9-z8FzvWbOZqbwzlKMaG9ib7NdRQVvhu3T=s256',
            'channel_id': ftv_asia_yt_channel,
            'isFolder': False, 'isPlayable': False
        },
        {
            'title': 'FashionTV News',
            'action': 'newpipe',
            'image': 'https://yt3.ggpht.com/a/AATXAJxw6UfiplqVo8OHZdMhoZAPOwcyjiKQQSYbdOaH=s256',
            'channel_id': ftv_news_channel,
            'isFolder': False, 'isPlayable': False
        }
    ]

    for item in self_list:
        ch_url = 'https://www.youtube.com/channel/{}'.format(item.pop('channel_id'))
        query = {
            'action': 'channel',
            'url': ch_url,
            'title': item['title']
        }
        item['url'] = 'plugin://plugin.video.newpipe/?{}'.format(urlencode(query))

    directory.builder(self_list)


@urldispatcher.register('newpipe', ['url'])
def newpipe(url):

    kodi.execute('Container.Update({},return)'.format(url))


@urldispatcher.register('youtube', ['url'])
def yt(url):

    keys_registration()
    kodi.execute('Container.Update({},return)'.format(url))


@urldispatcher.register('bookmarks')
def bookmarks():

    self_list = bms.get()

    if not self_list:
        na = [{'title': kodi.i18n(30007), 'action': None}]
        directory.builder(na)
        return

    for i in self_list:
        bookmark = dict((k, v) for k, v in i.items() if not k == 'next')
        try:
            bookmark['delbookmark'] = i['url']
        except KeyError:
            bookmark['delbookmark'] = i['query']
        i.update({'cm': [{'title': 30006, 'query': {'action': 'deleteBookmark', 'url': json.dumps(bookmark)}}]})
        if i.get('action') == 'playlist':
            i['isFolder'] = True
            i['isPlayable'] = False
        elif i.get('action') == 'play':
            i['isFolder'] = False
            i['isPlayable'] = True

    kodi.setsortmethod('none')
    kodi.setsortmethod('title')

    directory.builder(self_list, content='videos')


@urldispatcher.register('play', ['url'], ['title', 'image'])
def play(url, title=None, image=None):

    meta = {'title': title} if title else None
    directory.resolve(
        url,
        meta=meta,
        icon=image,
        dash=True,
        manifest_type='hls' if '.m3u8' in url else None,
        mimetype='application/x-mpegURL' if '.m3u8' in url else None
    )
