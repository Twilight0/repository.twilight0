# -*- coding: utf-8 -*-

'''
    Fashion TV Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import sys
from urllib.parse import parse_qsl
from urldispatcher import urldispatcher
from tulip.log import log

# noinspection PyProtectedMember, PyUnresolvedReferences
from resources.lib import navigator, utils


def main(argv=None):

    if argv is None:
        argv = sys.argv

    try:
        params = dict(parse_qsl(argv[2][1:]))
    except (IndexError, TypeError):
        params = {}

    action = params.get('action') or 'root'

    try:
        urldispatcher.dispatch(action, params)
    except Exception as e:
        log('Fashion TV: action |{0}| failed ({1})'.format(action, e))
        if action == 'play':
            try:
                from tulip import kodi
                handle = int(argv[1])
                kodi.resolve(handle, False, kodi.item())
            except Exception:
                pass
        elif action != 'root':
            try:
                urldispatcher.dispatch('root', {})
            except Exception:
                pass


if __name__ == '__main__':

    sys.exit(main())
