#Subtitles.gr global context menu item
###_Author: Twilight0_
