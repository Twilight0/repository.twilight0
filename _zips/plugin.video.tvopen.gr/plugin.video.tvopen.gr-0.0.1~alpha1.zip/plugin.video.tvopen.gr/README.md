
# Open TV Player addon for Kodi

## About

Open TV Live and on-demand broadcasts

Kodi Addon for https://www.tvopen.gr

This addon is not published nor endorsed by tvopen.gr

This addon offers content available in Greece

Main artwork from https://www.tvopen.gr

License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html