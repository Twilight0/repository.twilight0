ERTflix addon for Kodi
======================

![](https://raw.githubusercontent.com/Twilight0/plugin.video.ert.gr/master/icon.png)

About
-----
ERT live and on-demand broadcasts

Kodi Addon for https://www.ertflix.gr

This addon is not published nor endorsed by ert.gr

This addon offers content available in Greece

License
-------

[GNU GPL, version 3](https://raw.githubusercontent.com/Twilight0/plugin.video.ert.gr/master/LICENCES/GPL-3.0-only "Repo ZIP")