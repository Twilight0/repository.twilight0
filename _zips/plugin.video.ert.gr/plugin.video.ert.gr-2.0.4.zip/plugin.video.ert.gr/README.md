ERT Player addon for Kodi
======================

About
-----
ERT live and on-demand broadcasts

Kodi Addon for http://www.ert.gr

This addon is not published nor endorsed by ert.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

http://logos.wikia.com/wiki/ERT1?file=ERT1_2015.svg

http://logos.wikia.com/wiki/ERT2?file=ERT2_2015.svg

http://logos.wikia.com/wiki/ERT3?file=ERT3_2015.svg

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html