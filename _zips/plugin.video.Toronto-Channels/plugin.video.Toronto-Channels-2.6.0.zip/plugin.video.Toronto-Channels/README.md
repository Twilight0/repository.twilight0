BCI Greek TV addon for Kodi
======================

About
-----

Kodi Addon for [https://bcimedia.wixsite.com/bcimedia][2]

License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html
[2]: https://bcimedia.wixsite.com/bcimedia
