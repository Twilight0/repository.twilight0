# -*- coding: utf-8 -*-

"""
    Toronto Channels Add-on
    Author: BCI Media Inc.

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License, or
        (at your option) any later version.

        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import absolute_import
import json
from zlib import decompress
from base64 import b64decode


Melodia_url = 'https://cast.streams.ovh/sc/melodiatoronto/stream'
RIK_url = 'http://l3.cloudskep.com/cybcsat/abr/playlist.m3u8'
RIK_proto = 'http://r1.cloudskep.com/cybcr/cybc1/playlist.m3u8'
RIK_trito = 'http://r1.cloudskep.com/cybcr/cybc3/playlist.m3u8'
# SIGMA_url = 'http://81.21.47.74/hls/live.m3u8'
# CEWR_url = 'http://147.135.252.4:10221/live'
YT_Channel = 'UCKXFDK9dRGcnwr7mWmzoY2w'
mags_base_url = 'https://alivegr.net/bci_mags/index.txt'

# NETV_Toronto_url = ('https://www.netvtoronto.com/', 'Ahr0Chm6lY9SAxzLlNn0CMvHBxmUB3zOl1q0ndrutMfWv1ryEtrWl1q0ndrutMfWv1ryEtrWl3bSyxLSAxn0lM0ZDtG=')
# Cannali_url = ('https://www.cannalimusic.com/', 'Ahr0Chm6lY9SAxzLlNn0CMvHBxmUB3zOl3nLuuD4sdzTngeVC2vrr3HinM00ys9JAhvUA2XPC3rFDZeZntCWmJmWmY5Tm3u4')
# Life_url = ('https://www.lifehd.magicstreams.net/', 'Ahr0Chm6lY9SAxzLlNn0CMvHBxmUB3zOlZHnBw1uwMPAsfaVoe1TBvrAALPiuc9JAhvUA2XPC3rFDZe5mJeXmJmWmdiUBtn1oa==')


scramble = (
    'eJwVzM0OgiAAAOBXcZzLpaiwblmt2cHNXHlshoSm/AREWuvdmw/wfV/QNWDtgRAhjCMYJzAMlzJY6TbRSpgWUx3A2A1INOZppUNxyx5+rZTxmZRsoC'
    '9DNZHCUmF9IjlYeKBW3bWn09xusk9dTinKmzHYVq6fduKENWHBLXsXZKyY40c+nmdlKNHUziiP9gfMLrBitHAFx6S7K8zSEvz+QP85Rw=='
)


NETV_Toronto_url = 'https://live.streams.ovh:443/NetvToronto/NetvToronto/playlist.m3u8'
# NETV_Toronto_2_url = 'http://162.219.176.210/live/eugo242017p1a/playlist.m3u8'
# Eugo24_url = 'http://162.219.176.210:18935/live/eugo242017p1a/playlist.m3u8'
Cannali_url = 'https://live.streams.ovh:443/cannali/cannali/playlist.m3u8'
NEWS_url = 'https://live.streams.ovh:443/netmedia/netmedia/playlist.m3u8'
FOOD_url = 'https://channel.streams.ovh:19360/foodchannel/foodchannel.m3u8'
CETN_url = 'https://channel.streams.ovh:19360/cetn/cetn.m3u8'
HEALTH_url = 'https://eco.streams.ovh/healthchannel/healthchannel/playlist.m3u8'


keys = json.loads(decompress(b64decode(scramble)))
