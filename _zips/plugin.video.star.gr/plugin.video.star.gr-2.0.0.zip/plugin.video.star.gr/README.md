
STAR Player addon for Kodi
======================

About
-----
STAR live and on-demand broadcasts

Kodi Addon for http://www.star.gr

This addon is not published nor endorsed by star.gr

This addon offers content available in Greece

License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html