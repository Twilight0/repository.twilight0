# plugin.video.hng
A kodi plugin/addon featuring the youtube channel &amp; from Reto-Moto's Heroes and Generals PC Game. Extra features include the OST of the game and third party channels dedicated to H&amp;G gameplay.
