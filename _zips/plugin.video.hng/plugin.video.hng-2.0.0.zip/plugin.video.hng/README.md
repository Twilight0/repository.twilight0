# plugin.video.hng
A kodi plugin/addon featuring the youtube channel & from Reto-Moto's Heroes and Generals PC Game.
Extra features include the OST of the game and third party channels dedicated to H&G gameplay.

Not published or endorsed by Reto-Moto.
