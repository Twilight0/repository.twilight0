======================
SKAI Player addon for Kodi
======================

About
-----
SKAI live and on-demand broadcasts

Kodi Addon for http://www.skai.gr

This addon is not published nor endorsed by skai.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

http://logos.wikia.com/wiki/Skai_TV?file=SKAI-Logo.png

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html