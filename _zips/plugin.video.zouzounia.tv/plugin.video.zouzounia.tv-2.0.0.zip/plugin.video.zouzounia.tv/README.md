# plugin.video.zouzounia.tv
Kodi video addon for the Zouzounia TV Youtube channels (English, Greek &amp; Japanese)
