
ALPHA Player addon for Kodi
======================

About
-----
ALPHA live and on-demand broadcasts

Kodi Addon for http://www.alphatv.gr

This addon is not published nor endorsed by alphatv.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

http://logos.wikia.com/wiki/Alpha_TV?file=Alpha2013.svg

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html