The purpose of this addon is to test links which are supported by streamlink library resolver.
It can keep history of links user provides and it doesn't actively provide any on its own.
