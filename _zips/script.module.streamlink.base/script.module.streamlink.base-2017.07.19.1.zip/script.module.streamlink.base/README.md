# script.module.streamlink.base

Default Streamlink Library for Kodi Addon [neverreply/service.streamlink.proxy](https://github.com/neverreply/service.streamlink.proxy)

You can install it from [repository.neverreply](https://github.com/neverreply/repo)
