
Subtitles.gr addon for Kodi
======================

About
-----
Search and download subtitles from subtitles.gr, xsubs.tv and subztv.gr

Kodi Addon for http://www.subtitles.gr/, http://xsubs.tv/ and http://subztv.club/

This service is not published nor endorsed by subtitles.gr, xsubs.tv and subztv.club


Artwork
---------------------
Artwork sourced from public domain:

http://www.subtitles.gr/logo.jpg


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html