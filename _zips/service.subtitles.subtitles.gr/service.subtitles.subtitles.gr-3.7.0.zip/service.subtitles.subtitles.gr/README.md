
# Subtitles.gr addon for Kodi

------------

### About

Search and download subtitles from the following domains:

- Subtitles.gr
- Xsubs.tv
- Podnapisi.net
- Vipsubs.gr

This service is not published nor endorsed by the above mentioned domains

### Artwork

Artwork sourced from public domain:

http://www.subtitles.gr/logo.jpg


### License

This software is released under the [GPL 3.0 license](http://www.gnu.org/licenses/gpl-3.0.html).
