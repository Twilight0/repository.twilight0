# Size indicates importance

---

##### Fix proxy enabler

---

### Check youtube setup action

---

#### Add search music


#######################################################################################

- **Id will change to "plugin.program.alivegr":**

    You have nothing to worry about this actually, I'll do the replacement semi-automatically by asking users first

- **Search functionality has been revamped:** 

    Now you can search by action/actress or even director

#############################################################################
