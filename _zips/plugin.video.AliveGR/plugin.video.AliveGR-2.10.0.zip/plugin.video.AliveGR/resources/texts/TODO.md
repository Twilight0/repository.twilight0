# Size indicates importance

---

#### Add search music

---

#### Add switching scheme in the bookmarks section

---

### Make a wizard setup action

---

### Utilize url dispatcher

---

#### Build setup script
