# Size indicates importance

---

##### Fix/Enhance proxy enabler

---

#### Add search music

---

#### Introduce pagination on indexers over 150 items via a switcher

---

#### Add switching scheme in the bookmarks section

---

## Utilize url dispatcher

---

#### Combine kids indexers (greek-movies.com + gamatotv2.com)

---

### Allow precaching of certain sections of the addon

---

### Build mirror script

---

#### Build setup script
