# Size indicates importance

---

##### Fix proxy enabler

---

#### Add search music

---

#### Introduce pagination on indexers over 150 items via a switcher

---

#### Add switching scheme in the bookmarks section

---

## Utilize url dispatcher

---

#### Combine kids indexers (greek-movies.com + gamatotv2.com)

---

### Combine alternative live streams into a single item and give choice

- **Id will change to "plugin.program.alivegr":**

    You have nothing to worry about this actually, I'll do the replacement semi-automatically by asking users first
