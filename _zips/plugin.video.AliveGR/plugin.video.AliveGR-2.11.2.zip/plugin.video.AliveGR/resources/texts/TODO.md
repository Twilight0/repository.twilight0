# Size indicates importance

---

## Add switching scheme in the bookmarks section

---

#### Make a wizard setup action

---

### Utilize url dispatcher
