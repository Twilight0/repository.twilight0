# = AliveGR Kodi addon git repository =
## Your one addon for everything greek related

![](https://raw.githubusercontent.com/Twilight0/plugin.video.AliveGR/master/resources/media/icon.png)

- Live TV
- Radio
- Video on demand
- News
- Movies
- Kids
- Documentaries
- Sports
- Music on demand
- TV Series & TV Shows
- Short Films

**Primary OSes tested:**

- Windows 10 64 bit
- Ubuntu Linux 64 bit
- Android 5, 7 & 8

**Kodi Versions tested:**

- Leia 18.X (x64)

**Repository zip for updates:**

[repository.twilight0-1.2.zip](https://raw.githubusercontent.com/Twilight0/repo.twilight0/master/_zips/repository.twilight0/repository.twilight0-1.2.zip "Repo ZIP")

**Source url for the same zip to add into Kodi's file manager sources:**

[http://alivegr.net/master](http://alivegr.net/master "Repo ZIP")

It also has many tools and settings so that you can tweak your viewing experience.
**Have fun.**
Artwork is made by me. Icons were layered with existing flat icons from
######Flaticon.com: [Link](http://www.flaticon.com/ "Flaticon.com")
