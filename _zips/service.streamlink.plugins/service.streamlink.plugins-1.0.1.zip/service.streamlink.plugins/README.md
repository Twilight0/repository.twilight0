# service.streamlink.plugins

This Plugin is an **example plugin** which won't get updated.

You can use this plugin in your repository for custom **streamlink** plugins

Just copy your `....py` file into the _plugins_ folder.

## streamlink

The compatible streamlink Kodi plugin for this is [neverreply/service.streamlink.proxy](https://github.com/neverreply/service.streamlink.proxy)

You can find it in [repository.neverreply](https://github.com/neverreply/repo)
