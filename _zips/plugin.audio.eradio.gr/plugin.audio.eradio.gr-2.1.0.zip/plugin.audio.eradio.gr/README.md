#E-Radio addon for Kodi
### Developer: Twilight0
(credits to **lambda** for the original code)

----

##About

Tune-in to greek radios and listen live audio streams from e-radio.gr

This addon is not published nor endorsed by e-radio.gr


##Artwork

Artwork sourced from public domains:

http://ecx.images-amazon.com/images/I/41OhtJ5A0BL.png

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


##License

This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html