pycountry - 17.5.14
==============

pycountry repacked for Kodi

Source: https://bitbucket.org/flyingcircus/pycountry

Version: [17.5.14](https://bitbucket.org/flyingcircus/pycountry/commits/tag/17.5.14)
