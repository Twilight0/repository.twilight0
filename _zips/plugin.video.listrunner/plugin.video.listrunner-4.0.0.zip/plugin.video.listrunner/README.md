# plugin.video.listrunner
Listrunner addon allows loading of custom m3u playlists
