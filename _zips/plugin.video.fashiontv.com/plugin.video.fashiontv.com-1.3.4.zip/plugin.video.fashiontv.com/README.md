
# Fashion TV Player addon for Kodi

## About

Fashion TV Live and on-demand broadcasts

Kodi Addon for https://www.fashiontv.com

This addon is not published nor endorsed by fashiontv.com

Main artwork from https://www.fashiontv.com

License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html