ANT1 Player addon for Kodi
======================

About
-----
ANT1 live and on-demand broadcasts

Kodi Addon for http://www.antenna.gr

This addon is not published nor endorsed by antenna.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

http://logos.wikia.com/wiki/ANT1?file=Ant1-logo.jpg

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html