# script.module.ordereddict - 1.1

- Github: [repository.neverreply](https://github.com/neverreply/repo)
- Source: https://pypi.python.org/pypi/ordereddict
