======================
Vice addon for Kodi
======================

About
-----
Vice changes the way people think about culture, crime, technology, art, sex, music, fashion, sports, and more.

Kodi Addon for http://www.vice.com

This addon is not published nor endorsed by vice.com


Artwork
---------------------
Artwork sourced from public domain:

https://en.wikipedia.org/wiki/Vice_Media#/media/File:Vice_logo.svg


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html